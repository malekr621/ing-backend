# API CRUD Centre

Projet d'exemple en Node.js, Express, Prisma, MySQL et Zod.

## Installation rapide
```bash
npm install
```
Créer une base `gestion_centres` dans MySQL, copier `.env.example` vers `.env`, puis modifier le mot de passe et l'utilisateur MySQL.

```bash
npx prisma generate
npx prisma migrate dev --name create_centre
npm run dev
```

API : `http://localhost:3000/api/centres`

Prisma Studio :
```bash
npx prisma studio
```

Voir `compte_rendu.md` pour le rapport et `tests/curl-tests.md` pour les tests.

**Important :** le modèle Centre fourni est un exemple (`nom`, `adresse`, `telephone`, `email`). Adaptez-le si votre sujet ou votre base utilise d'autres champs.
