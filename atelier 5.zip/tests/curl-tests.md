# Tests avec curl (Windows PowerShell / CMD)

Remplacer `1` par l'identifiant réellement retourné lors de la création.

## 1. POST — Créer
```bash
curl -X POST http://localhost:3000/api/centres -H "Content-Type: application/json" -d "{\"nom\":\"Centre Nord\",\"adresse\":\"Tunis\",\"telephone\":\"20111222\",\"email\":\"nord@example.com\"}"
```

## 2. GET — Tous les centres
```bash
curl http://localhost:3000/api/centres
```

## 3. GET — Un centre
```bash
curl http://localhost:3000/api/centres/1
```

## 4. PUT — Remplacer tous les champs modifiables
```bash
curl -X PUT http://localhost:3000/api/centres/1 -H "Content-Type: application/json" -d "{\"nom\":\"Centre Nord Modifié\",\"adresse\":\"Ariana\",\"telephone\":\"22123456\",\"email\":\"nord.modifie@example.com\"}"
```

## 5. PATCH — Modifier seulement certains champs
```bash
curl -X PATCH http://localhost:3000/api/centres/1 -H "Content-Type: application/json" -d "{\"adresse\":\"La Marsa\"}"
```

## 6. DELETE — Supprimer
```bash
curl -X DELETE http://localhost:3000/api/centres/1
```

Tester aussi les erreurs : identifiant inexistant (`/9999`), identifiant invalide (`/abc`), email invalide et corps JSON vide.
