#!/bin/bash
BASE_URL="http://localhost:3000/api/centres"

echo "1. Créer un centre"
curl -i -X POST "$BASE_URL" \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre Nord","adresse":"Tunis","telephone":"20111222","email":"nord@example.com"}'

echo -e "\n2. Lister les centres"
curl -i "$BASE_URL"

echo -e "\n3. Consulter le centre numéro 1"
curl -i "$BASE_URL/1"

echo -e "\n4. Remplacer les informations du centre numéro 1 (PUT)"
curl -i -X PUT "$BASE_URL/1" \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre Nord Modifié","adresse":"Ariana","telephone":"22123456","email":"nord.modifie@example.com"}'

echo -e "\n5. Modifier seulement l'adresse (PATCH)"
curl -i -X PATCH "$BASE_URL/1" \
  -H "Content-Type: application/json" \
  -d '{"adresse":"La Marsa"}'

echo -e "\n6. Supprimer le centre numéro 1"
curl -i -X DELETE "$BASE_URL/1"
