import express from "express";
import centreRoutes from "./routes/centre.routes.js";
import { errorHandler } from "./middlewares/errorHandler.js";

const app = express();

app.use(express.json());
app.get("/", (req, res) => res.json({ message: "API Centres opérationnelle" }));
app.use("/api/centres", centreRoutes);
app.use(errorHandler);

export default app;
