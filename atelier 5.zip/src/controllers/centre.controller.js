import { centreService } from "../services/centre.service.js";

export const centreController = {
  async findAll(req, res, next) {
    try {
      const centres = await centreService.findAll();
      res.status(200).json(centres);
    } catch (error) {
      next(error);
    }
  },

  async findById(req, res, next) {
    try {
      const centre = await centreService.findById(req.params.id);
      res.status(200).json(centre);
    } catch (error) {
      next(error);
    }
  },

  async create(req, res, next) {
    try {
      const centre = await centreService.create(req.body);
      res.status(201).json({
        message: "Centre créé avec succès",
        data: centre
      });
    } catch (error) {
      next(error);
    }
  },

  async update(req, res, next) {
    try {
      const centre = await centreService.update(req.params.id, req.body);
      res.status(200).json({
        message: "Centre remplacé avec succès",
        data: centre
      });
    } catch (error) {
      next(error);
    }
  },

  async patch(req, res, next) {
    try {
      const centre = await centreService.patch(req.params.id, req.body);
      res.status(200).json({
        message: "Centre modifié avec succès",
        data: centre
      });
    } catch (error) {
      next(error);
    }
  },

  async remove(req, res, next) {
    try {
      await centreService.remove(req.params.id);
      res.status(200).json({ message: "Centre supprimé avec succès" });
    } catch (error) {
      next(error);
    }
  }
};
