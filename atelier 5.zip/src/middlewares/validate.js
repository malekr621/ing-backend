export function validate({ body, params }) {
  return (req, res, next) => {
    if (body) {
      const result = body.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          message: "Données invalides",
          erreurs: result.error.flatten().fieldErrors
        });
      }
      req.body = result.data;
    }

    if (params) {
      const result = params.safeParse(req.params);
      if (!result.success) {
        return res.status(400).json({
          message: "Paramètres invalides",
          erreurs: result.error.flatten().fieldErrors
        });
      }
      req.params = result.data;
    }

    next();
  };
}
