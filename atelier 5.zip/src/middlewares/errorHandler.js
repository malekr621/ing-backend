export function errorHandler(error, req, res, next) {
  console.error(error);

  if (error.code === "P2002") {
    return res.status(409).json({ message: "Cette valeur existe déjà (email unique)." });
  }

  if (error.code === "P2025") {
    return res.status(404).json({ message: "Centre introuvable." });
  }

  res.status(error.status || 500).json({
    message: error.status ? error.message : "Erreur interne du serveur"
  });
}
