import { z } from "zod";

const centreSchema = z.object({
  nom: z.string().trim().min(2, "Le nom doit contenir au moins 2 caractères").max(150),
  adresse: z.string().trim().min(3, "L'adresse est obligatoire").max(255),
  telephone: z.string().trim().max(30).optional().nullable(),
  email: z.string().trim().email("Adresse e-mail invalide").max(150).optional().nullable()
});

export const createCentreSchema = centreSchema;

export const updateCentreSchema = centreSchema;

export const patchCentreSchema = centreSchema.partial().refine(
  (data) => Object.keys(data).length > 0,
  { message: "Fournissez au moins un champ à modifier" }
);

export const idParamSchema = z.object({
  id: z.coerce.number().int().positive("L'identifiant doit être un entier positif")
});
