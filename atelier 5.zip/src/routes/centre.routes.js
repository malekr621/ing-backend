import { Router } from "express";
import { centreController } from "../controllers/centre.controller.js";
import {
  createCentreSchema,
  updateCentreSchema,
  patchCentreSchema,
  idParamSchema
} from "../validators/centre.validator.js";
import { validate } from "../middlewares/validate.js";

const router = Router();

router.get("/", centreController.findAll);
router.get("/:id", validate({ params: idParamSchema }), centreController.findById);
router.post("/", validate({ body: createCentreSchema }), centreController.create);
router.put("/:id",
  validate({ params: idParamSchema }),
  validate({ body: updateCentreSchema }),
  centreController.update
);
router.patch("/:id",
  validate({ params: idParamSchema }),
  validate({ body: patchCentreSchema }),
  centreController.patch
);
router.delete("/:id", validate({ params: idParamSchema }), centreController.remove);

export default router;
