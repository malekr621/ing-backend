import prisma from "../config/prisma.js";

export const centreRepository = {
  findAll() {
    return prisma.centre.findMany({ orderBy: { id: "asc" } });
  },

  findById(id) {
    return prisma.centre.findUnique({ where: { id } });
  },

  create(data) {
    return prisma.centre.create({ data });
  },

  update(id, data) {
    return prisma.centre.update({ where: { id }, data });
  },

  remove(id) {
    return prisma.centre.delete({ where: { id } });
  }
};
