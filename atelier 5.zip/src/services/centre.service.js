import { centreRepository } from "../repositories/centre.repository.js";

export const centreService = {
  findAll() {
    return centreRepository.findAll();
  },

  async findById(id) {
    const centre = await centreRepository.findById(id);
    if (!centre) {
      const error = new Error("Centre introuvable");
      error.status = 404;
      throw error;
    }
    return centre;
  },

  create(data) {
    return centreRepository.create(data);
  },

  async update(id, data) {
    await this.findById(id);
    return centreRepository.update(id, data);
  },

  async patch(id, data) {
    await this.findById(id);
    return centreRepository.update(id, data);
  },

  async remove(id) {
    await this.findById(id);
    await centreRepository.remove(id);
  }
};
