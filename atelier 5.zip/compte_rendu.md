# Compte rendu — API CRUD des Centres

## 1. Objectif
L'objectif est de développer une API REST permettant de gérer les centres (Create, Read, Update, Delete) avec Node.js, Express, Prisma ORM, MySQL et Zod.

## 2. Technologies
- Node.js : environnement JavaScript côté serveur.
- Express : création des routes HTTP.
- Prisma : communication entre l'application et MySQL.
- MySQL : stockage des données.
- Zod : validation des données reçues.
- curl : tests des endpoints HTTP.
- Prisma Studio : consultation visuelle des données.

## 3. Arborescence du projet
```text
centre-crud-api/
├── prisma/
│   ├── migrations/
│   │   └── 20261108000000_create_centre/
│   │       └── migration.sql
│   └── schema.prisma
├── src/
│   ├── config/prisma.js
│   ├── controllers/centre.controller.js
│   ├── middlewares/
│   │   ├── errorHandler.js
│   │   └── validate.js
│   ├── repositories/centre.repository.js
│   ├── routes/centre.routes.js
│   ├── services/centre.service.js
│   ├── validators/centre.validator.js
│   ├── app.js
│   └── server.js
├── tests/
│   ├── curl-tests.md
│   └── curl-tests.sh
├── .env.example
├── package.json
└── compte_rendu.md
```

## 4. Modèle Prisma
Le modèle `Centre` contient :
- `id` : identifiant unique auto-incrémenté.
- `nom` : nom du centre.
- `adresse` : adresse du centre.
- `telephone` : numéro de téléphone facultatif.
- `email` : adresse e-mail facultative et unique.
- `createdAt` : date de création.
- `updatedAt` : date de dernière modification.

Le modèle est défini dans `prisma/schema.prisma`.

## 5. Migration
La migration SQL crée la table `Centre`, sa clé primaire et l'index unique sur `email`.

Commandes :
```bash
npx prisma generate
npx prisma migrate dev --name create_centre
```
La migration fournie est un exemple correspondant au modèle. Dans un projet existant, il est préférable de générer la migration avec Prisma plutôt que d'exécuter manuellement un doublon.

## 6. Repository
Le fichier `centre.repository.js` contient les opérations d'accès aux données :
- `findAll()` : récupérer tous les centres.
- `findById(id)` : récupérer un centre par son identifiant.
- `create(data)` : ajouter un centre.
- `update(id, data)` : modifier un centre.
- `remove(id)` : supprimer un centre.

Le Repository communique directement avec Prisma. Il ne contient pas la logique HTTP.

## 7. Service
Le Service applique la logique métier. Il vérifie notamment qu'un centre existe avant une modification ou une suppression. Si le centre n'existe pas, il déclenche une erreur 404.

## 8. Controller
Le Controller reçoit les requêtes, appelle le Service et construit les réponses HTTP :
- 200 : opération réussie.
- 201 : centre créé.
- 400 : données ou paramètres invalides.
- 404 : centre introuvable.
- 409 : email déjà utilisé.
- 500 : erreur interne.

## 9. Routes
| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/centres` | Lister les centres |
| GET | `/api/centres/:id` | Consulter un centre |
| POST | `/api/centres` | Créer un centre |
| PUT | `/api/centres/:id` | Remplacer les champs modifiables |
| PATCH | `/api/centres/:id` | Modifier partiellement un centre |
| DELETE | `/api/centres/:id` | Supprimer un centre |

## 10. Validation
Zod vérifie les données avant leur arrivée dans le Controller :
- le nom doit contenir au moins 2 caractères ;
- l'adresse est obligatoire ;
- l'e-mail doit respecter le format d'une adresse e-mail ;
- l'identifiant doit être un entier positif ;
- PATCH doit contenir au moins un champ.

## 11. Tests avec curl
Les commandes de test sont disponibles dans `tests/curl-tests.md` et `tests/curl-tests.sh`.

Pour chaque opération, vérifier :
- le code HTTP retourné ;
- le message ou les données JSON ;
- le résultat réel dans la base de données.

**Captures à insérer dans le rapport :**
1. Résultat de `GET /api/centres`.
2. Réponse après `POST`.
3. Réponse après `PUT` et `PATCH`.
4. Réponse après `DELETE`.
5. Prisma Studio affichant les enregistrements de la table `Centre`.

Les captures doivent être réalisées sur votre propre environnement après exécution du projet.

## 12. Vérification de la base de données

Lancer Prisma Studio :
```bash
npx prisma studio
```

Dans MySQL :
```sql
USE gestion_centres;
SELECT * FROM Centre;
```

## 13. Explication du flux
1. **HTTP** : le client envoie une requête (GET, POST, PUT, PATCH ou DELETE).
2. **Route** : Express identifie l'URL et la méthode HTTP.
3. **Validation** : Zod vérifie les paramètres et le corps de la requête.
4. **Controller** : reçoit la requête validée et appelle le Service.
5. **Service** : applique les règles métier et vérifie l'existence du centre.
6. **Repository** : exécute l'opération de persistance avec Prisma.
7. **Prisma** : transforme l'appel JavaScript en requête SQL.
8. **MySQL** : stocke ou retourne les données.
9. La réponse remonte vers le client sous forme de JSON avec un code HTTP adapté.

## 14. Installation et démarrage

1. Installer les dépendances :
```bash
npm install
```

2. Créer une base MySQL :
```sql
CREATE DATABASE gestion_centres;
```

3. Copier `.env.example` vers `.env`, puis adapter les identifiants MySQL dans `DATABASE_URL`.

4. Générer Prisma et appliquer la migration :
```bash
npx prisma generate
npx prisma migrate dev --name create_centre
```

5. Démarrer le serveur :
```bash
npm run dev
```

6. Ouvrir Prisma Studio dans un autre terminal :
```bash
npx prisma studio
```

7. Exécuter les tests curl.

## 15. Conclusion
Cette réalisation met en place une API REST organisée en couches. La séparation entre Route, Validation, Controller, Service et Repository rend le code plus lisible, maintenable et facile à tester.
