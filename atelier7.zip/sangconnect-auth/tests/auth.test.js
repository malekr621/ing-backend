import { test, describe, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import jwt from "jsonwebtoken";
import app from "../src/app.js";
import { prisma } from "../src/lib/prisma.js";

const creds = { email: "malek@test.com", password: "motdepasse123" };

const makeToken = (role = "DONNEUR", options = { expiresIn: "1h" }) =>
  jwt.sign({ sub: "1", email: creds.email, role }, process.env.JWT_SECRET, options);

beforeEach(async () => { await prisma.user.deleteMany(); });
after(async () => { await prisma.$disconnect(); });

describe("Inscription / connexion", () => {
  test("Inscription réussie", async () => {
    const res = await request(app).post("/api/auth/register").send(creds);
    assert.equal(res.status, 201);
    assert.equal(res.body.user.email, creds.email);
    assert.equal(res.body.user.role, "DONNEUR");
    assert.equal(res.body.user.passwordHash, undefined);
  });

  test("Email déjà utilisé", async () => {
    await request(app).post("/api/auth/register").send(creds);
    const res = await request(app).post("/api/auth/register").send(creds);
    assert.equal(res.status, 409);
  });

  test("Mot de passe incorrect", async () => {
    await request(app).post("/api/auth/register").send(creds);
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: creds.email, password: "mauvaismdp123" });
    assert.equal(res.status, 401);
  });

  test("Utilisateur inexistant", async () => {
    const res = await request(app).post("/api/auth/login").send(creds);
    assert.equal(res.status, 401);
  });

  test("Login réussi", async () => {
    await request(app).post("/api/auth/register").send(creds);
    const res = await request(app).post("/api/auth/login").send(creds);
    assert.equal(res.status, 200);
    const payload = jwt.verify(res.body.token, process.env.JWT_SECRET);
    assert.equal(payload.email, creds.email);
    assert.equal(payload.role, "DONNEUR");
    assert.ok(payload.sub && payload.exp);
  });
});

describe("Protection des routes", () => {
  test("Token absent", async () => {
    const res = await request(app).get("/api/auth/me");
    assert.equal(res.status, 401);
    assert.equal(res.body.code, "TOKEN_MISSING");
  });

  test("Token invalide", async () => {
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", "Bearer pas.un.token");
    assert.equal(res.status, 401);
    assert.equal(res.body.code, "TOKEN_INVALID");
  });

  test("Token expiré", async () => {
    const expired = makeToken("DONNEUR", { expiresIn: -10 });
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", `Bearer ${expired}`);
    assert.equal(res.status, 401);
    assert.equal(res.body.code, "TOKEN_EXPIRED");
  });

  // Nécessite que /api/centres soit monté dans app.js avec authorize() (voir README)
  test("Rôle insuffisant", async () => {
    const res = await request(app)
      .post("/api/centres")
      .set("Authorization", `Bearer ${makeToken("DONNEUR")}`)
      .send({});
    assert.equal(res.status, 403);
  });

  test("Accès autorisé", async () => {
    await request(app).post("/api/auth/register").send(creds);
    const { body } = await request(app).post("/api/auth/login").send(creds);
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", `Bearer ${body.token}`);
    assert.equal(res.status, 200);
    assert.equal(res.body.user.email, creds.email);
  });
});
