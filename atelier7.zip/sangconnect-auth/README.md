# SangConnect — Authentification (mini-projet)

## Installation
```bash
npm i bcryptjs jsonwebtoken zod
npm i -D supertest
```
Ajoutez dans `package.json` :
```json
"scripts": { "test": "node --env-file=.env.test --test tests/" }
```

## Étapes
1. Copier le contenu de `src/` et `tests/` dans votre projet (ignorer `validate.js`, `lib/prisma.js`,
   `error-handler.js`, `app.js` si vous avez déjà les vôtres : fusionnez).
2. Ajouter `prisma/user-model.prisma` à votre `schema.prisma`, puis :
   `npx prisma migrate dev --name add_user`
3. Créer `.env` et `.env.test` à partir des fichiers `.example`.
4. Monter les routes : `app.use("/api/auth", authRoutes)` et `app.use(errorHandler)` en dernier.
5. Protéger les routes centres comme dans `src/routes/centre.routes.protected.example.js`
   et monter `/api/centres` dans `app.js` (nécessaire pour le test « Rôle insuffisant »).
6. Lancer : `npm test`

## Routes
| Méthode | Route                | Accès          | Succès |
|---------|----------------------|----------------|--------|
| POST    | /api/auth/register   | public         | 201    |
| POST    | /api/auth/login      | public         | 200    |
| GET     | /api/auth/me         | authentifié    | 200    |

Erreurs : 400 validation, 401 token absent/invalide/expiré ou identifiants invalides,
403 rôle insuffisant, 409 email déjà utilisé.

## Tests curl
```bash
curl -X POST localhost:3000/api/auth/register -H "Content-Type: application/json" \
  -d '{"email":"malek@test.com","password":"motdepasse123"}'

TOKEN=$(curl -s -X POST localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"malek@test.com","password":"motdepasse123"}' | jq -r .token)

curl localhost:3000/api/auth/me -H "Authorization: Bearer $TOKEN"
```

## Notes de sécurité
- Le rôle n'est jamais lu depuis le body (tout le monde s'inscrit DONNEUR). Pour créer un ADMIN,
  modifiez la colonne `role` via Prisma Studio.
- Message identique pour utilisateur inexistant et mauvais mot de passe.
- 401 = non identifié ; 403 = identifié mais droits insuffisants.
