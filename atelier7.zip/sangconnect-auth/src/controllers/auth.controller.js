import * as authService from "../services/auth.service.js";

export async function register(req, res, next) {
  try {
    const user = await authService.register(req.body);
    res.status(201).json({ user });
  } catch (e) { next(e); }
}

export async function login(req, res, next) {
  try {
    res.status(200).json(await authService.login(req.body));
  } catch (e) { next(e); }
}

export async function me(req, res, next) {
  try {
    res.status(200).json({ user: await authService.getProfile(req.user.id) });
  } catch (e) { next(e); }
}
