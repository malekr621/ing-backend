import { Router } from "express";
import { validate } from "../middlewares/validate.js";
import { registerSchema, loginSchema } from "../validators/auth.validator.js";
import { authenticate } from "../middlewares/authenticate.js";
import * as ctrl from "../controllers/auth.controller.js";

const router = Router();
router.post("/register", validate(registerSchema, "body"), ctrl.register);
router.post("/login", validate(loginSchema, "body"), ctrl.login);
router.get("/me", authenticate, ctrl.me);
export default router;
