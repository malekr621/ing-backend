// EXEMPLE : à recopier dans votre src/routes/centre.routes.js existant.
import { authenticate } from "../middlewares/authenticate.js";
import { authorize } from "../middlewares/authorize.js";

router.get("/", authenticate, ctrl.list);                 // tout utilisateur connecté
router.get("/:id", authenticate, ctrl.getOne);
router.post("/", authenticate, authorize("ADMIN", "PERSONNEL"), validate(/* ... */), ctrl.create);
router.put("/:id", authenticate, authorize("ADMIN", "PERSONNEL"), validate(/* ... */), ctrl.update);
router.patch("/:id", authenticate, authorize("ADMIN", "PERSONNEL"), validate(/* ... */), ctrl.patch);
router.delete("/:id", authenticate, authorize("ADMIN"), ctrl.remove);
