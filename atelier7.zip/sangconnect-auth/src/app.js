// EXEMPLE minimal : fusionnez avec votre app.js / server.js existant.
// L'app est exportée SANS listen() pour que supertest puisse l'utiliser.
import express from "express";
import authRoutes from "./routes/auth.routes.js";
// import centreRoutes from "./routes/centre.routes.js";
import { errorHandler } from "./middlewares/error-handler.js";

const app = express();
app.use(express.json());

app.use("/api/auth", authRoutes);
// app.use("/api/centres", centreRoutes);

app.use(errorHandler); // toujours en dernier
export default app;
