import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { userRepository } from "../repositories/user.repository.js";
import { HttpError } from "../utils/http-error.js";

const toPublic = ({ passwordHash, ...user }) => user;

function signToken(user) {
  return jwt.sign(
    { sub: String(user.id), email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { algorithm: "HS256", expiresIn: process.env.JWT_EXPIRES_IN ?? "1h" }
  );
}

export async function register({ email, password }) {
  if (await userRepository.findByEmail(email)) {
    throw new HttpError(409, "Email déjà utilisé", "EMAIL_TAKEN");
  }
  const passwordHash = await bcrypt.hash(password, 10);
  // Le rôle n'est JAMAIS lu depuis le body : tout le monde s'inscrit DONNEUR.
  const user = await userRepository.create({ email, passwordHash });
  return toPublic(user);
}

export async function login({ email, password }) {
  const user = await userRepository.findByEmail(email);
  const ok = user && (await bcrypt.compare(password, user.passwordHash));
  // Même message pour "utilisateur inexistant" et "mauvais mot de passe"
  if (!ok) throw new HttpError(401, "Identifiants invalides", "INVALID_CREDENTIALS");
  return { token: signToken(user), user: toPublic(user) };
}

export async function getProfile(id) {
  const user = await userRepository.findById(id);
  if (!user) throw new HttpError(401, "Utilisateur introuvable", "USER_NOT_FOUND");
  return toPublic(user);
}
