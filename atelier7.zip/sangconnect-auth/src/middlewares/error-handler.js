// À fusionner avec votre gestionnaire d'erreurs existant si vous en avez déjà un.
export function errorHandler(err, req, res, next) {
  const status = err.status ?? 500;
  if (status === 500) console.error(err);
  res.status(status).json({
    error: status === 500 ? "Erreur interne" : err.message,
    code: err.code,
  });
}
