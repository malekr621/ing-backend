import { HttpError } from "../utils/http-error.js";

export const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return next(new HttpError(401, "Non authentifié", "UNAUTHENTICATED"));
  if (!roles.includes(req.user.role)) {
    return next(new HttpError(403, "Accès interdit : rôle insuffisant", "FORBIDDEN"));
  }
  next();
};
