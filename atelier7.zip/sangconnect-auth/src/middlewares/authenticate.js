import jwt from "jsonwebtoken";
import { HttpError } from "../utils/http-error.js";

export function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return next(new HttpError(401, "Token manquant", "TOKEN_MISSING"));
  }
  try {
    const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET, {
      algorithms: ["HS256"],
    });
    req.user = { id: Number(payload.sub), email: payload.email, role: payload.role };
    next();
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      return next(new HttpError(401, "Token expiré", "TOKEN_EXPIRED"));
    }
    next(new HttpError(401, "Token invalide", "TOKEN_INVALID"));
  }
}
