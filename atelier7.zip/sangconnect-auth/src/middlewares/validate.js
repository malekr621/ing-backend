// À ignorer si vous avez déjà votre validate(schema, source) (TP 52-53).
import { HttpError } from "../utils/http-error.js";

export const validate = (schema, source = "body") => (req, res, next) => {
  const result = schema.safeParse(req[source]);
  if (!result.success) {
    const message = result.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    return next(new HttpError(400, message, "VALIDATION_ERROR"));
  }
  req[source] = result.data;
  next();
};
