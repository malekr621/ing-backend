# SangConnect : validation complète de la ressource Centre (Express + Zod)

API REST des centres de collecte avec validation de `req.body`, `req.params` et `req.query` par Zod.

## 1. Lancement

Prérequis : Node.js 18 ou plus récent.

```bash
npm install        # installe express et zod
npm start          # démarre sur http://localhost:3000
npm test           # lance les 42 tests automatisés
```

Port personnalisé : `PORT=4000 npm start`.

Versions utilisées : Express 5 et Zod 4. Le code des schémas utilise l'option `error:` de Zod 4 ; avec Zod 3, il faudrait la remplacer par `message` / `required_error`.

## 2. Structure

```
sangconnect-express/
├── package.json
├── README.md
├── src/
│   ├── server.js                       # lance l'application sur un port
│   ├── app.js                          # assemble Express : JSON, routes, 404, gestionnaire d'erreurs
│   ├── routes/
│   │   └── centre.routes.js            # (URL, méthode) -> middlewares de validation -> controller
│   ├── controllers/
│   │   └── centre.controller.js        # HTTP <-> service, choix du code de réponse
│   ├── services/
│   │   └── centre.service.js           # logique métier (existence, doublons)
│   ├── validators/
│   │   └── centre.validator.js         # schémas Zod (body, params, query)
│   ├── middlewares/
│   │   ├── validate.js                 # validate(schema, source) : middleware générique
│   │   ├── error-handler.js            # gestion centralisée des erreurs
│   │   ├── not-found.js                # 404 JSON
│   │   └── method-not-allowed.js       # 405 JSON + en-tête Allow
│   ├── data/
│   │   └── centres.data.js             # données fictives en mémoire
│   └── utils/
│       └── errors.js                   # AppError, ValidationError, NotFoundError...
└── tests/
    └── centres.test.js                 # tests automatisés (node:test)
```

## 3. Chemin d'une requête

```
Requête HTTP
   │
   ▼
express.json()                      lit le corps -> req.body
   │
   ▼
routes/centre.routes.js             choisit la chaîne de middlewares selon (URL, méthode)
   │
   ▼
middlewares/validate(schema, src)   valide req.params, puis req.query ou req.body (Zod)
   │                                 -> valide : données rangées dans req.validated, next()
   │                                 -> invalide : next(ValidationError)  ──────────┐
   ▼                                                                                │
controllers/centre.controller       lit req.validated, appelle le service,          │
   │                                 choisit 200 / 201 / 204                        │
   ▼                                                                                │
services/centre.service             règles métier : 404 (inexistant), 409 (doublon) │
   │                                 -> lève une AppError en cas de problème ───────┤
   ▼                                                                                │
data/centres.data.js                tableau en mémoire                              │
                                                                                    ▼
                                    middlewares/error-handler : toute erreur -> réponse JSON
```

Les données validées sont dans `req.validated.params`, `req.validated.query` et `req.validated.body`. Les objets d'origine (`req.body`, `req.params`, `req.query`) ne sont pas modifiés : Express 5 rend `req.query` en lecture seule.

## 4. Routes

| Méthode  | Route                       | Validation                                   | Succès | Erreurs possibles |
|----------|-----------------------------|----------------------------------------------|--------|-------------------|
| `GET`    | `/api/centres`              | `query` : `ville` facultatif                 | 200    | 400               |
| `GET`    | `/api/centres?ville=Sousse` | `query` : `ville` de 2 à 60 caractères       | 200    | 400               |
| `GET`    | `/api/centres/:id`          | `params` : `id` entier > 0                   | 200    | 400, 404          |
| `POST`   | `/api/centres`              | `body` : 4 champs obligatoires               | 201    | 400, 409          |
| `PUT`    | `/api/centres/:id`          | `params` + `body` : 4 champs obligatoires    | 200    | 400, 404, 409     |
| `PATCH`  | `/api/centres/:id`          | `params` + `body` : au moins 1 champ         | 200    | 400, 404, 409     |
| `DELETE` | `/api/centres/:id`          | `params` : `id` entier > 0                   | 204    | 400, 404          |
| autre méthode sur ces URL    |                             |                                              | —      | 405 + `Allow`     |
| URL inconnue                 |                             |                                              | —      | 404               |

### Règles de validation (schémas Zod)

| Champ       | Règle                                                                    |
|-------------|--------------------------------------------------------------------------|
| `nom`       | texte, espaces retirés, 2 à 100 caractères                               |
| `ville`     | texte, espaces retirés, 2 à 60 caractères                                |
| `adresse`   | texte, espaces retirés, 5 à 200 caractères                               |
| `telephone` | 8 à 15 chiffres, espaces autorisés, `+` possible au début                |
| `id` (URL)  | entier strictement positif (`1`, `25` ; pas `0`, `-1`, `1.5`, `abc`, `01`) |

- `POST` et `PUT` : les 4 champs sont obligatoires.
- `PATCH` : tous facultatifs, mais au moins un.
- Tout champ non prévu est refusé (y compris `id` dans le corps), dans le corps comme dans la query (`?page=2` donne 400).
- `?ville=a&ville=b` (paramètre répété) donne 400.
- Pour une même requête, les sources sont validées dans l'ordre `params` puis `body` : la première source invalide arrête la chaîne.

### Format des erreurs

Toutes les erreurs ont la même forme, produite par le gestionnaire central :

```json
{
  "error": "Données invalides",
  "message": "La requête ne respecte pas le format attendu.",
  "status": 400,
  "details": [
    { "source": "body", "champ": "nom", "message": "\"nom\" est obligatoire." },
    { "source": "body", "champ": "telephone", "message": "\"telephone\" invalide : 8 à 15 chiffres, espaces autorisés, \"+\" au début possible." }
  ]
}
```

Le champ `details` n'existe que pour les erreurs de validation. La route inconnue renvoie en plus `path`, `method` et `timestamp`.

### Codes de statut utilisés

| Code | Signification         | Quand ?                                                              |
|------|-----------------------|----------------------------------------------------------------------|
| 200  | OK                    | Lecture, remplacement ou modification réussie                        |
| 201  | Created               | Création (en-tête `Location: /api/centres/<id>`)                     |
| 204  | No Content            | Suppression réussie, sans corps                                      |
| 400  | Bad Request           | Validation Zod échouée, JSON mal formé, URL mal encodée              |
| 404  | Not Found             | Centre inexistant, ou URL inconnue                                   |
| 405  | Method Not Allowed    | Méthode non prévue sur une URL existante (en-tête `Allow`)           |
| 409  | Conflict              | Même nom de centre déjà présent dans la même ville                   |
| 413  | Payload Too Large     | Corps supérieur à 100 Ko                                             |
| 500  | Internal Server Error | Erreur inattendue (message générique, détail dans la console)        |

## 5. Commandes curl

```bash
# Lecture
curl -i http://localhost:3000/api/centres
curl -i http://localhost:3000/api/centres/1
curl -i "http://localhost:3000/api/centres?ville=Sousse"

# Validation de req.params -> 400
curl -i http://localhost:3000/api/centres/abc

# Validation de req.query -> 400
curl -i "http://localhost:3000/api/centres?ville="
curl -i "http://localhost:3000/api/centres?page=2"

# Création -> 201
curl -i -X POST http://localhost:3000/api/centres \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre de Collecte de Bizerte","ville":"Bizerte","adresse":"14 Rue du Port","telephone":"72 000 006"}'

# Validation de req.body -> 400 (nom trop court, telephone invalide, champ inconnu)
curl -i -X POST http://localhost:3000/api/centres \
  -H "Content-Type: application/json" \
  -d '{"nom":"A","ville":"Bizerte","adresse":"14 Rue du Port","telephone":"abc","id":99}'

# Remplacement complet -> 200
curl -i -X PUT http://localhost:3000/api/centres/6 \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre Régional de Bizerte","ville":"Bizerte","adresse":"20 Avenue de la Mer","telephone":"72 000 060"}'

# Modification partielle -> 200
curl -i -X PATCH http://localhost:3000/api/centres/6 \
  -H "Content-Type: application/json" \
  -d '{"telephone":"72 111 111"}'

# Suppression -> 204
curl -i -X DELETE http://localhost:3000/api/centres/6

# Méthode non autorisée -> 405
curl -i -X DELETE http://localhost:3000/api/centres

# Route inconnue -> 404
curl -i http://localhost:3000/api/inconnue
```

> Windows PowerShell : utilisez `curl.exe` à la place de `curl`, ou Git Bash pour les commandes ci-dessus.

---

## 6. Travail de réflexion

### Question 1 : pourquoi ne faut-il pas faire toute la validation dans le contrôleur ?

1. **Duplication.** `POST` et `PUT` partagent les mêmes règles, `PATCH` en reprend une partie, et `params` et `query` ont les leurs. Dans les contrôleurs, chaque règle serait recopiée dans plusieurs fonctions, puis oubliée ou modifiée à un seul endroit.
2. **Une seule responsabilité.** Le contrôleur traduit HTTP <-> service. S'il vérifie aussi chaque champ, il devient long et illisible, et le code utile se noie dans une série de `if`.
3. **Sécurité par construction.** Avec un middleware placé avant le contrôleur, il est impossible d'atteindre le contrôleur avec des données invalides : il reçoit uniquement des données propres (`req.validated`). Si la validation est écrite dans chaque contrôleur, une route peut l'oublier.
4. **Règles déclaratives.** Un schéma Zod décrit ce qui est attendu (« 2 à 100 caractères »). Une suite de `if` décrit comment le vérifier, avec davantage de bugs possibles.
5. **Testabilité.** On teste un schéma seul, sans serveur ni contrôleur.

### Question 2 : quelle est la différence entre validation et logique métier ?

La **validation** vérifie que les données sont bien formées : présence, type, longueur, format. Elle se décide **à partir de la requête seule**, sans consulter l'état de l'application. La **logique métier** applique les règles du domaine, qui dépendent **du contexte et de l'état des données**.

| Validation (validators, 400)                    | Logique métier (service, 404 / 409)                          |
|-------------------------------------------------|--------------------------------------------------------------|
| `telephone` : 8 à 15 chiffres                   | Un centre portant ce nom existe-t-il déjà dans cette ville ? (409) |
| `id` : entier strictement positif               | Existe-t-il un centre avec cet id ? (404)                    |
| `nom` : 2 à 100 caractères                      | `PUT` ne crée pas de centre, il remplace un centre existant  |
| `PATCH` : au moins un champ                     | Fusionner les anciens champs et les nouveaux, sans changer l'id |
| Champ inconnu refusé                            |                                                              |

Test simple : si on peut répondre sans regarder les données stockées, c'est de la validation ; sinon, c'est du métier. Exemple : `id = 999` est un entier valide (la validation passe), mais aucun centre ne porte cet id (le service répond 404).

### Question 3 : quel est l'intérêt d'un middleware générique `validate(schema, source)` ?

- **Écrit une seule fois, utilisé partout.** `validate(idParamsSchema, 'params')`, `validate(listeQuerySchema, 'query')` et `validate(centreCompletSchema, 'body')` partagent le même code. Valider une nouvelle ressource, c'est écrire des schémas, pas un nouveau middleware.
- **Les routes se lisent comme une recette** : `.put(validate(id, 'params'), validate(corps, 'body'), controller.remplacer)`.
- **Format d'erreur uniforme.** Toutes les erreurs de validation ont la même forme (`source`, `champ`, `message`), quelle que soit la source.
- **Contrôleurs allégés.** Ils lisent `req.validated` et ne contiennent aucune vérification.
- **Remplaçable.** Si l'on change de bibliothèque de validation, seuls `validate.js` et les schémas changent ; routes, contrôleurs et services restent intacts.
- **Erreur de configuration détectée tôt.** `validate(schema, 'boby')` échoue au démarrage du serveur, pas au premier appel.

### Question 4 : pourquoi centraliser la gestion des erreurs ?

- **Cohérence.** Tous les clients reçoivent le même format (`error`, `message`, `status`, `details`), pour une erreur de validation, un 404 ou un 500.
- **Moins de code répété.** Sans centralisation, chaque contrôleur contient un `try/catch` et construit sa réponse d'erreur. Ici, les contrôleurs n'ont aucun `try/catch` : le service lève une `AppError`, et le gestionnaire la convertit.
- **Un seul endroit pour la correspondance erreur -> code HTTP.** Changer un message ou un code se fait une fois.
- **Sécurité.** Les erreurs inattendues sont journalisées côté serveur, mais le client reçoit un message générique : ni trace d'appels, ni détail interne.
- **Gestion des erreurs hors de notre code.** Le même gestionnaire traite un JSON mal formé (`express.json()`), une URL mal encodée ou un corps trop gros, qui surviennent avant nos contrôleurs.
- **Évolution.** Ajouter une journalisation ou une surveillance des erreurs se fait à un seul endroit.

### Question 5 : quelle couche sera ajoutée dans l'Atelier 5 pour remplacer les données en mémoire ?

La couche **Repository** (couche d'accès aux données / persistance), reliée à une vraie base de données. Le service appellera ses fonctions (`findAll`, `findById`, `create`, `update`, `remove`...) au lieu de manipuler le tableau de `src/data/centres.data.js`. Routes, validators, middlewares et contrôleurs ne changeront pas. Cette réponse s'appuie sur la progression du cours ; je n'ai pas le contenu de l'Atelier 5.

Schéma cible :

```
Route -> Validators / Middlewares -> Controller -> Service -> Repository -> Base de données
```
