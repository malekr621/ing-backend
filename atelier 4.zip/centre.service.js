'use strict';

const { centres, genererId } = require('../data/centres.data');
const { NotFoundError, ConflictError } = require('../utils/errors');

/**
 * Couche SERVICE : logique métier.
 * Elle reçoit des données DÉJÀ validées (forme correcte, types convertis) par les
 * middlewares Zod ; elle ne vérifie plus le format, seulement les règles qui dépendent
 * de l'état des données : le centre existe-t-il ? Ce nom est-il déjà pris dans cette ville ?
 * Elle ignore tout de HTTP (req, res).
 */

/** Compare sans tenir compte de la casse ni des accents. */
function normaliser(texte) {
  return texte
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

function trouverIndex(id) {
  const index = centres.findIndex((c) => c.id === id);
  if (index === -1) {
    throw new NotFoundError(`Aucun centre avec l'identifiant ${id}.`);
  }
  return index;
}

/** Règle métier : pas deux centres de même nom dans la même ville. */
function verifierUnicite(nom, ville, idIgnore) {
  const doublon = centres.find(
    (c) => c.id !== idIgnore && normaliser(c.nom) === normaliser(nom) && normaliser(c.ville) === normaliser(ville)
  );
  if (doublon) {
    throw new ConflictError(`Un centre nommé "${nom}" existe déjà à ${ville} (id ${doublon.id}).`);
  }
}

function lister(ville) {
  const resultat = ville === undefined ? centres : centres.filter((c) => normaliser(c.ville) === normaliser(ville));
  return resultat.map((c) => ({ ...c }));
}

function lireParId(id) {
  return { ...centres[trouverIndex(id)] };
}

function creer(donnees) {
  verifierUnicite(donnees.nom, donnees.ville);
  const centre = { id: genererId(), ...donnees };
  centres.push(centre);
  return { ...centre };
}

/** PUT : remplacement complet. Le centre doit exister (PUT ne crée pas). */
function remplacer(id, donnees) {
  const index = trouverIndex(id);
  verifierUnicite(donnees.nom, donnees.ville, id);
  centres[index] = { id, ...donnees };
  return { ...centres[index] };
}

/** PATCH : seuls les champs fournis changent. */
function modifier(id, modifications) {
  const index = trouverIndex(id);
  const fusion = { ...centres[index], ...modifications, id };
  verifierUnicite(fusion.nom, fusion.ville, id);
  centres[index] = fusion;
  return { ...fusion };
}

function supprimer(id) {
  centres.splice(trouverIndex(id), 1);
}

module.exports = { lister, lireParId, creer, remplacer, modifier, supprimer };
