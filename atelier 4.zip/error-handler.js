'use strict';

const { AppError } = require('../utils/errors');

/**
 * Gestionnaire d'erreurs CENTRALISÉ : un seul endroit transforme toute erreur en réponse JSON.
 * Express le reconnaît à ses 4 paramètres (err, req, res, next) ; il doit être déclaré en dernier.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Réponse déjà commencée : on laisse Express fermer la connexion.
  if (res.headersSent) {
    return next(err);
  }

  let status;
  let error;
  let message;
  let details;
  let headers;

  if (err instanceof AppError) {
    // Erreur prévue (400, 404, 405, 409...)
    ({ status, error, message, details, headers } = err);
  } else if (err.type === 'entity.parse.failed') {
    // JSON mal formé, détecté par express.json()
    status = 400;
    error = 'JSON invalide';
    message = 'Le corps de la requête n\'est pas un JSON valide.';
  } else if (err.type === 'entity.too.large') {
    status = 413;
    error = 'Corps trop volumineux';
    message = 'Le corps de la requête dépasse la taille autorisée.';
  } else if (err instanceof URIError) {
    // URL mal encodée (ex. /api/centres/%E0%A4%A), détectée par Express avant nos routes
    status = 400;
    error = 'URL invalide';
    message = 'L\'URL contient une séquence d\'encodage invalide.';
  } else if (Number.isInteger(err.status) && err.status >= 400 && err.status < 500) {
    // Autre erreur client signalée par une bibliothèque (ex. corps illisible)
    status = err.status;
    error = 'Requête invalide';
    message = 'La requête n\'a pas pu être traitée.';
  } else {
    // Erreur inattendue : détail dans la console, message générique pour le client.
    console.error('[ERREUR]', err);
    status = 500;
    error = 'Erreur interne du serveur';
    message = 'Une erreur est survenue lors du traitement de la requête.';
  }

  if (headers) res.set(headers);

  const corps = { error, message, status };
  if (details) corps.details = details;
  res.status(status).json(corps);
}

module.exports = { errorHandler };
