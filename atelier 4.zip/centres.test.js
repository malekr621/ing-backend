'use strict';

/**
 * Tests de l'API /api/centres.
 * Lancement : npm test
 *
 * Les tests s'exécutent dans l'ordre et partagent les données en mémoire :
 * la création (id 6) précède les tests PUT / PATCH / DELETE qui l'utilisent.
 */

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { creerApp } = require('../src/app');

let serveur;
let base;

before(async () => {
  serveur = creerApp().listen(0);
  await new Promise((resolve) => serveur.once('listening', resolve));
  base = `http://localhost:${serveur.address().port}`;
});

after(() => serveur.close());

/** Envoie une requête ; `corps` objet -> JSON, chaîne -> envoyée telle quelle. */
async function requete(methode, chemin, corps) {
  const options = { method: methode, headers: {} };
  if (corps !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = typeof corps === 'string' ? corps : JSON.stringify(corps);
  }
  const reponse = await fetch(base + chemin, options);
  const texte = await reponse.text();
  return { status: reponse.status, headers: reponse.headers, texte, json: texte ? JSON.parse(texte) : null };
}

const CENTRE_VALIDE = {
  nom: 'Centre de Collecte de Bizerte',
  ville: 'Bizerte',
  adresse: '14 Rue du Port',
  telephone: '72 000 006',
};

// ---------------------------------------------------------------------------
// GET /api/centres  (+ validation de req.query)
// ---------------------------------------------------------------------------

test('GET /api/centres : liste complète (200)', async () => {
  const r = await requete('GET', '/api/centres');
  assert.equal(r.status, 200);
  assert.equal(r.json.length, 5);
});

test('GET /api/centres?ville=Sousse : filtre par ville (200)', async () => {
  const r = await requete('GET', '/api/centres?ville=Sousse');
  assert.equal(r.status, 200);
  assert.equal(r.json.length, 2);
  assert.ok(r.json.every((c) => c.ville === 'Sousse'));
});

test('GET ?ville=sousse : insensible à la casse', async () => {
  const r = await requete('GET', '/api/centres?ville=sousse');
  assert.equal(r.json.length, 2);
});

test('GET ?ville=Kairouan : ville valide sans centre -> liste vide (200)', async () => {
  const r = await requete('GET', '/api/centres?ville=Kairouan');
  assert.equal(r.status, 200);
  assert.deepEqual(r.json, []);
});

test('GET ?ville= (vide) -> 400, source "query"', async () => {
  const r = await requete('GET', '/api/centres?ville=');
  assert.equal(r.status, 400);
  assert.equal(r.json.details[0].source, 'query');
  assert.equal(r.json.details[0].champ, 'ville');
});

test('GET ?ville=a (trop court) -> 400', async () => {
  const r = await requete('GET', '/api/centres?ville=a');
  assert.equal(r.status, 400);
});

test('GET ?ville=a&ville=b (paramètre répété) -> 400', async () => {
  const r = await requete('GET', '/api/centres?ville=Tunis&ville=Sfax');
  assert.equal(r.status, 400);
});

test('GET ?page=2 (paramètre inconnu) -> 400', async () => {
  const r = await requete('GET', '/api/centres?page=2');
  assert.equal(r.status, 400);
  assert.match(r.json.details[0].message, /page/);
});

// ---------------------------------------------------------------------------
// GET /api/centres/:id  (+ validation de req.params)
// ---------------------------------------------------------------------------

test('GET /api/centres/1 -> 200', async () => {
  const r = await requete('GET', '/api/centres/1');
  assert.equal(r.status, 200);
  assert.equal(r.json.id, 1);
  assert.equal(typeof r.json.id, 'number');
});

test('GET /api/centres/999 -> 404', async () => {
  const r = await requete('GET', '/api/centres/999');
  assert.equal(r.status, 404);
});

for (const id of ['abc', '0', '-1', '1.5', '01']) {
  test(`GET /api/centres/${id} (id invalide) -> 400, source "params"`, async () => {
    const r = await requete('GET', `/api/centres/${id}`);
    assert.equal(r.status, 400);
    assert.equal(r.json.details[0].source, 'params');
  });
}

test('GET URL mal encodée -> 400, le serveur reste disponible', async () => {
  const r = await requete('GET', '/api/centres/%E0%A4%A');
  assert.equal(r.status, 400);
  assert.equal((await requete('GET', '/api/centres/1')).status, 200);
});

// ---------------------------------------------------------------------------
// POST /api/centres  (+ validation de req.body)
// ---------------------------------------------------------------------------

test('POST valide -> 201, Location, id généré, espaces retirés', async () => {
  const r = await requete('POST', '/api/centres', { ...CENTRE_VALIDE, nom: '  Centre de Collecte de Bizerte  ' });
  assert.equal(r.status, 201);
  assert.equal(r.json.id, 6);
  assert.equal(r.json.nom, 'Centre de Collecte de Bizerte');
  assert.equal(r.headers.get('location'), '/api/centres/6');
});

test('POST sans corps -> 400, 4 champs obligatoires signalés', async () => {
  const r = await requete('POST', '/api/centres');
  assert.equal(r.status, 400);
  assert.deepEqual(r.json.details.map((d) => d.champ).sort(), ['adresse', 'nom', 'telephone', 'ville']);
});

test('POST avec types incorrects -> 400', async () => {
  const r = await requete('POST', '/api/centres', { ...CENTRE_VALIDE, nom: 123, ville: null });
  assert.equal(r.status, 400);
  assert.equal(r.json.details.length, 2);
});

test('POST avec telephone invalide -> 400', async () => {
  const r = await requete('POST', '/api/centres', { ...CENTRE_VALIDE, nom: 'Autre', telephone: 'abc' });
  assert.equal(r.status, 400);
  assert.equal(r.json.details[0].champ, 'telephone');
});

test('POST avec nom trop court -> 400', async () => {
  const r = await requete('POST', '/api/centres', { ...CENTRE_VALIDE, nom: 'A' });
  assert.equal(r.status, 400);
});

test('POST avec champ inconnu (id) -> 400', async () => {
  const r = await requete('POST', '/api/centres', { ...CENTRE_VALIDE, nom: 'Autre', id: 99 });
  assert.equal(r.status, 400);
  assert.match(r.json.details[0].message, /id/);
});

test('POST avec un tableau JSON -> 400', async () => {
  const r = await requete('POST', '/api/centres', []);
  assert.equal(r.status, 400);
});

test('POST avec JSON mal formé -> 400', async () => {
  const r = await requete('POST', '/api/centres', '{"nom": ');
  assert.equal(r.status, 400);
  assert.equal(r.json.error, 'JSON invalide');
});

test('POST doublon nom + ville -> 409 (règle métier, pas de validation)', async () => {
  const r = await requete('POST', '/api/centres', CENTRE_VALIDE);
  assert.equal(r.status, 409);
});

// ---------------------------------------------------------------------------
// PUT /api/centres/:id
// ---------------------------------------------------------------------------

test('PUT valide -> 200, remplacement complet', async () => {
  const r = await requete('PUT', '/api/centres/6', {
    nom: 'Centre Régional de Bizerte',
    ville: 'Bizerte',
    adresse: '20 Avenue de la Mer',
    telephone: '72 000 060',
  });
  assert.equal(r.status, 200);
  assert.equal(r.json.id, 6);
  assert.equal(r.json.adresse, '20 Avenue de la Mer');
});

test('PUT incomplet -> 400', async () => {
  const r = await requete('PUT', '/api/centres/6', { nom: 'Seulement le nom' });
  assert.equal(r.status, 400);
});

test('PUT sur id inexistant -> 404 (PUT ne crée pas)', async () => {
  const r = await requete('PUT', '/api/centres/999', CENTRE_VALIDE);
  assert.equal(r.status, 404);
});

test('PUT avec id ET corps invalides -> 400, l\'erreur "params" est signalée en premier', async () => {
  const r = await requete('PUT', '/api/centres/abc', {});
  assert.equal(r.status, 400);
  assert.equal(r.json.details[0].source, 'params');
});

test('PUT qui reprend le nom d\'un autre centre de la même ville -> 409', async () => {
  const r = await requete('PUT', '/api/centres/6', { ...CENTRE_VALIDE, nom: 'Centre Régional de Sousse', ville: 'Sousse' });
  assert.equal(r.status, 409);
});

// ---------------------------------------------------------------------------
// PATCH /api/centres/:id
// ---------------------------------------------------------------------------

test('PATCH partiel -> 200, seuls les champs envoyés changent', async () => {
  const r = await requete('PATCH', '/api/centres/6', { telephone: '72 111 111' });
  assert.equal(r.status, 200);
  assert.equal(r.json.telephone, '72 111 111');
  assert.equal(r.json.nom, 'Centre Régional de Bizerte');
});

test('PATCH avec objet vide -> 400', async () => {
  const r = await requete('PATCH', '/api/centres/6', {});
  assert.equal(r.status, 400);
});

test('PATCH avec id dans le corps -> 400', async () => {
  const r = await requete('PATCH', '/api/centres/6', { id: 99 });
  assert.equal(r.status, 400);
});

test('PATCH avec valeur invalide -> 400', async () => {
  const r = await requete('PATCH', '/api/centres/6', { telephone: '12' });
  assert.equal(r.status, 400);
});

test('PATCH sur id inexistant -> 404', async () => {
  const r = await requete('PATCH', '/api/centres/999', { telephone: '72 111 111' });
  assert.equal(r.status, 404);
});

// ---------------------------------------------------------------------------
// DELETE /api/centres/:id
// ---------------------------------------------------------------------------

test('DELETE -> 204 sans corps, puis le centre n\'existe plus (404)', async () => {
  const r = await requete('DELETE', '/api/centres/6');
  assert.equal(r.status, 204);
  assert.equal(r.texte, '');
  assert.equal((await requete('GET', '/api/centres/6')).status, 404);
});

test('DELETE sur id inexistant -> 404', async () => {
  assert.equal((await requete('DELETE', '/api/centres/999')).status, 404);
});

test('DELETE avec id invalide -> 400', async () => {
  assert.equal((await requete('DELETE', '/api/centres/abc')).status, 400);
});

// ---------------------------------------------------------------------------
// 405, 404 et enchaînement
// ---------------------------------------------------------------------------

test('DELETE /api/centres -> 405 avec Allow: GET, POST', async () => {
  const r = await requete('DELETE', '/api/centres');
  assert.equal(r.status, 405);
  assert.equal(r.headers.get('allow'), 'GET, POST');
  assert.ok(r.json.message.includes('/api/centres'));
});

test('POST /api/centres/1 -> 405 avec Allow', async () => {
  const r = await requete('POST', '/api/centres/1', CENTRE_VALIDE);
  assert.equal(r.status, 405);
  assert.equal(r.headers.get('allow'), 'GET, PUT, PATCH, DELETE');
});

test('Route inconnue -> 404 JSON', async () => {
  const r = await requete('GET', '/api/inconnue');
  assert.equal(r.status, 404);
  assert.equal(r.json.error, 'Route non trouvée');
  assert.equal(r.json.path, '/api/inconnue');
  assert.equal(r.json.method, 'GET');
  assert.ok(r.json.timestamp);
});

test('Plusieurs routes à la suite', async () => {
  const statuts = [];
  for (const [m, u] of [['GET', '/api/centres'], ['GET', '/api/centres/2'], ['GET', '/api/centres/999'], ['GET', '/api/inconnue']]) {
    statuts.push((await requete(m, u)).status);
  }
  assert.deepEqual(statuts, [200, 200, 404, 404]);
});
