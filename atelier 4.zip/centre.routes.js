'use strict';

const express = require('express');
const controller = require('../controllers/centre.controller');
const { validate } = require('../middlewares/validate');
const { methodNotAllowed } = require('../middlewares/method-not-allowed');
const {
  idParamsSchema,
  listeQuerySchema,
  centreCompletSchema,
  centrePartielSchema,
} = require('../validators/centre.validator');

/**
 * Couche ROUTES : pour chaque (URL, méthode), la chaîne de middlewares puis le controller.
 * Lecture : validate(params) -> validate(body) -> controller.
 */
const router = express.Router();

// /api/centres
router
  .route('/')
  .get(validate(listeQuerySchema, 'query'), controller.lister)
  .post(validate(centreCompletSchema, 'body'), controller.creer)
  .all(methodNotAllowed(['GET', 'POST']));

// /api/centres/:id
router
  .route('/:id')
  .get(validate(idParamsSchema, 'params'), controller.lireParId)
  .put(validate(idParamsSchema, 'params'), validate(centreCompletSchema, 'body'), controller.remplacer)
  .patch(validate(idParamsSchema, 'params'), validate(centrePartielSchema, 'body'), controller.modifier)
  .delete(validate(idParamsSchema, 'params'), controller.supprimer)
  .all(methodNotAllowed(['GET', 'PUT', 'PATCH', 'DELETE']));

module.exports = router;
