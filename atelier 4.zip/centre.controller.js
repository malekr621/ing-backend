'use strict';

const centreService = require('../services/centre.service');

/**
 * Couche CONTROLLER : traduit HTTP <-> service.
 * Lit les données validées (req.validated), appelle le service, choisit le code de réponse.
 * Aucune validation ici, aucun try/catch : les erreurs remontent au gestionnaire central
 * (Express 5 capte aussi les erreurs levées dans une fonction synchrone).
 */

function lister(req, res) {
  const { ville } = req.validated.query;
  res.status(200).json(centreService.lister(ville));
}

function lireParId(req, res) {
  const { id } = req.validated.params;
  res.status(200).json(centreService.lireParId(id));
}

function creer(req, res) {
  const centre = centreService.creer(req.validated.body);
  res.status(201).location(`/api/centres/${centre.id}`).json(centre);
}

function remplacer(req, res) {
  const { id } = req.validated.params;
  res.status(200).json(centreService.remplacer(id, req.validated.body));
}

function modifier(req, res) {
  const { id } = req.validated.params;
  res.status(200).json(centreService.modifier(id, req.validated.body));
}

function supprimer(req, res) {
  const { id } = req.validated.params;
  centreService.supprimer(id);
  res.status(204).end();
}

module.exports = { lister, lireParId, creer, remplacer, modifier, supprimer };
