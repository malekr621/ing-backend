'use strict';

const { z } = require('zod');

/**
 * Schémas Zod de la ressource Centre.
 * Rôle : vérifier la FORME des données (présence, type, longueur, format).
 * Les règles qui demandent de consulter les données (existence, doublon)
 * restent dans le service : ce sont des règles métier.
 */

// --- Champs réutilisables -------------------------------------------------

/** Message adapté : champ absent (undefined) ou de mauvais type. */
const erreurChaine = (libelle) => (issue) =>
  issue.input === undefined
    ? `"${libelle}" est obligatoire.`
    : `"${libelle}" doit être une chaîne de caractères.`;

const texte = (libelle, min, max) =>
  z
    .string({ error: erreurChaine(libelle) })
    .trim()
    .min(min, `"${libelle}" doit contenir au moins ${min} caractères.`)
    .max(max, `"${libelle}" ne doit pas dépasser ${max} caractères.`);

const champsCentre = {
  nom: texte('nom', 2, 100),
  ville: texte('ville', 2, 60),
  adresse: texte('adresse', 5, 200),
  telephone: z
    .string({ error: erreurChaine('telephone') })
    .trim()
    .regex(/^\+?[0-9 ]{8,15}$/, '"telephone" invalide : 8 à 15 chiffres, espaces autorisés, "+" au début possible.'),
};

const ERREUR_OBJET = { error: 'Un objet JSON est attendu.' };

// --- req.params -----------------------------------------------------------

/** /api/centres/:id : l'id arrive en texte, on vérifie puis on convertit en nombre. */
const idParamsSchema = z.object(
  {
    id: z
      .string()
      .regex(/^[1-9]\d*$/, '"id" doit être un entier strictement positif.')
      .transform(Number),
  },
  ERREUR_OBJET
);

// --- req.query ------------------------------------------------------------

/** GET /api/centres?ville=Sousse : « ville » est facultatif, mais s'il est présent il doit être valide. */
const listeQuerySchema = z
  .object(
    {
      ville: texte('ville', 2, 60).optional(),
    },
    ERREUR_OBJET
  )
  .strict();

// --- req.body -------------------------------------------------------------

/** POST et PUT : les 4 champs sont obligatoires, aucun champ inconnu (id compris). */
const centreCompletSchema = z.object(champsCentre, ERREUR_OBJET).strict();

/** PATCH : tous les champs sont facultatifs, mais il en faut au moins un. */
const centrePartielSchema = z
  .object(champsCentre, ERREUR_OBJET)
  .partial()
  .strict()
  .refine((donnees) => Object.keys(donnees).length > 0, {
    error: 'Au moins un champ à modifier est requis (nom, ville, adresse, telephone).',
    // Ne s'exécute que si les vérifications précédentes n'ont signalé aucune erreur
    // (évite un message redondant quand un champ inconnu a déjà été refusé).
    when: (payload) => payload.issues.length === 0,
  });

module.exports = {
  idParamsSchema,
  listeQuerySchema,
  centreCompletSchema,
  centrePartielSchema,
};
