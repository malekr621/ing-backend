'use strict';

const { ValidationError } = require('../utils/errors');

const SOURCES = ['body', 'params', 'query'];

/**
 * Transforme les erreurs Zod en liste lisible : [{ source, champ, message }].
 */
function formaterIssues(issues, source) {
  return issues.map((issue) => {
    // Un champ non prévu : le message Zod par défaut ne dit pas lequel -> on le précise.
    if (issue.code === 'unrecognized_keys') {
      return {
        source,
        champ: issue.keys.join(', '),
        message:
          issue.keys.includes('id') && source === 'body'
            ? 'Champ non autorisé : "id" n\'est pas modifiable.'
            : `Champ(s) non autorisé(s) : ${issue.keys.join(', ')}.`,
      };
    }
    return { source, champ: issue.path.join('.') || '(racine)', message: issue.message };
  });
}

/**
 * Middleware générique de validation.
 *
 * @param {import('zod').ZodType} schema  schéma Zod à appliquer
 * @param {'body'|'params'|'query'} source  partie de la requête à valider
 *
 * Si les données sont valides : le résultat (nettoyé, converti) est rangé dans
 * req.validated[source], puis next().
 * Sinon : next(ValidationError) -> le gestionnaire d'erreurs répond 400.
 *
 * Les objets req.body / req.params / req.query ne sont pas modifiés : Express 5
 * rend req.query en lecture seule, et laisser l'original intact évite les surprises.
 */
function validate(schema, source) {
  if (!SOURCES.includes(source)) {
    // Erreur de programmation détectée au démarrage, pas au premier appel.
    throw new Error(`validate(): source "${source}" inconnue (attendu : ${SOURCES.join(', ')}).`);
  }

  return (req, res, next) => {
    // Sans corps JSON, Express 5 laisse req.body à undefined : on valide alors un objet vide
    // pour obtenir les messages « champ obligatoire » plutôt qu'une erreur de type.
    const donnees = source === 'body' ? (req.body ?? {}) : req[source];

    const resultat = schema.safeParse(donnees);

    if (!resultat.success) {
      return next(new ValidationError(formaterIssues(resultat.error.issues, source)));
    }

    req.validated = { ...req.validated, [source]: resultat.data };
    next();
  };
}

module.exports = { validate };
