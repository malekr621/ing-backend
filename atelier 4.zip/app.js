'use strict';

const express = require('express');
const centreRoutes = require('./routes/centre.routes');
const { notFound } = require('./middlewares/not-found');
const { errorHandler } = require('./middlewares/error-handler');

/**
 * Construction de l'application Express (sans écouter sur un port :
 * cela permet de la réutiliser dans les tests).
 */
function creerApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json({ limit: '100kb' })); // lit le corps JSON -> req.body

  app.use('/api/centres', centreRoutes);

  app.use(notFound);      // 1. URL inconnue -> 404
  app.use(errorHandler);  // 2. toute erreur -> réponse JSON (doit être déclaré en dernier)

  return app;
}

module.exports = { creerApp };
