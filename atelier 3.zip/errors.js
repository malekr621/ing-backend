'use strict';

/**
 * Erreur applicative portant un code HTTP.
 * Les couches basses (service) la lèvent, la couche haute (controller) la traduit en réponse.
 */
class AppError extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
}

class NotFoundError extends AppError {
  constructor(message) {
    super(404, 'Ressource non trouvée', message);
  }
}

class BadRequestError extends AppError {
  constructor(message) {
    super(400, 'Requête invalide', message);
  }
}

class ConflictError extends AppError {
  constructor(message) {
    super(409, 'Conflit', message);
  }
}

class PayloadTooLargeError extends AppError {
  constructor(message) {
    super(413, 'Corps de requête trop volumineux', message);
  }
}

module.exports = { AppError, NotFoundError, BadRequestError, ConflictError, PayloadTooLargeError };
