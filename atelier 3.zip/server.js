'use strict';

const http = require('http');
const { sendJson, sendMethodNotAllowed, sendNotFound } = require('./utils/http');
const { handleDonneurRoutes } = require('./routes/donneur.routes');
const { handleCentreRoutes } = require('./routes/centre.routes');

const PORT = process.env.PORT || 3000;
const APP_NAME = 'SangConnect';
const API_VERSION = '1.0.0';

/**
 * Table des routes : chemin -> { méthodes autorisées, gestionnaire }
 */
const routes = {
  '/api/welcome': {
    methods: ['GET'],
    handler: (req, res) => {
      sendJson(res, 200, {
        message: 'Bienvenue dans l’API SangConnect',
        description: 'Gestion des dons de sang',
      });
    },
  },

  '/api/version': {
    methods: ['GET'],
    handler: (req, res) => {
      sendJson(res, 200, {
        application: APP_NAME,
        apiVersion: API_VERSION,
        nodeVersion: process.version,
        environment: process.env.NODE_ENV || 'development',
      });
    },
  },

  '/api/diagnostic': {
    methods: ['GET'],
    handler: (req, res) => {
      sendJson(res, 200, {
        method: req.method,
        url: req.url,
        date: new Date().toISOString(),
        headers: req.headers,
      });
    },
  },
};

const server = http.createServer((req, res) => {
  const { pathname, searchParams } = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  // Routes en couches (routes -> controller -> service -> repository)
  if (handleDonneurRoutes(req, res, pathname, searchParams)) {
    return;
  }
  if (handleCentreRoutes(req, res, pathname, searchParams)) {
    return;
  }

  const route = routes[pathname];

  // 1. Route inconnue -> 404
  if (!route) {
    return sendNotFound(req, res, pathname);
  }

  // 2. Méthode non autorisée -> 405
  if (!route.methods.includes(req.method)) {
    return sendMethodNotAllowed(req, res, pathname, route.methods);
  }

  // 3. Tout est bon -> on exécute le gestionnaire
  route.handler(req, res);
});

server.listen(PORT, () => {
  console.log(`${APP_NAME} démarré sur http://localhost:${PORT}`);
});
