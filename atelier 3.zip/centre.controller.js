'use strict';

const centreService = require('../services/centre.service');
const { sendJson, sendNoContent, sendError } = require('../utils/http');
const { readJsonBody } = require('../utils/body');

/**
 * Couche CONTROLLER : lit la requête HTTP (id, query, corps JSON),
 * appelle le service, puis écrit la réponse (code + JSON).
 * Les erreurs levées par le service sont converties en codes HTTP par sendError().
 */

function getAll(req, res, searchParams) {
  try {
    const ville = searchParams.has('ville') ? searchParams.get('ville') : undefined;
    sendJson(res, 200, centreService.getCentres(ville));
  } catch (err) {
    sendError(res, err);
  }
}

function getById(req, res, id) {
  try {
    sendJson(res, 200, centreService.getCentreById(id));
  } catch (err) {
    sendError(res, err);
  }
}

async function create(req, res) {
  try {
    const donnees = await readJsonBody(req);
    const centre = centreService.createCentre(donnees);
    sendJson(res, 201, centre, { Location: `/api/centres/${centre.id}` });
  } catch (err) {
    sendError(res, err);
  }
}

async function replace(req, res, id) {
  try {
    const donnees = await readJsonBody(req);
    sendJson(res, 200, centreService.replaceCentre(id, donnees));
  } catch (err) {
    sendError(res, err);
  }
}

async function patch(req, res, id) {
  try {
    const donnees = await readJsonBody(req);
    sendJson(res, 200, centreService.patchCentre(id, donnees));
  } catch (err) {
    sendError(res, err);
  }
}

function remove(req, res, id) {
  try {
    centreService.deleteCentre(id);
    sendNoContent(res);
  } catch (err) {
    sendError(res, err);
  }
}

module.exports = { getAll, getById, create, replace, patch, remove };
