'use strict';

const centreRepository = require('../repositories/centre.repository');
const { NotFoundError, BadRequestError, ConflictError } = require('../utils/errors');

/**
 * Couche SERVICE : validation et règles métier.
 * Elle ne connaît ni HTTP (req/res) ni la manière dont les données sont stockées.
 */

const CHAMPS = ['nom', 'ville', 'adresse', 'telephone'];

/** Convertit l'id reçu dans l'URL (texte) en nombre, ou lève une erreur 400. */
function parseId(idBrut) {
  if (!/^\d+$/.test(idBrut)) {
    throw new BadRequestError(`L'identifiant "${idBrut}" est invalide : un nombre entier est attendu.`);
  }
  return Number(idBrut);
}

/**
 * Valide les champs d'un corps de requête.
 * @param {object} donnees
 * @param {boolean} complet  true (POST, PUT) : les 4 champs sont obligatoires
 *                           false (PATCH)   : au moins un champ, les autres sont facultatifs
 * @returns {object} données nettoyées (chaînes sans espaces superflus)
 */
function valider(donnees, complet) {
  const problemes = [];

  const inconnus = Object.keys(donnees).filter((cle) => !CHAMPS.includes(cle));
  if (inconnus.length > 0) {
    const detail = inconnus.includes('id') ? ' (l\'identifiant "id" n\'est pas modifiable)' : '';
    problemes.push(`champs non autorisés : ${inconnus.join(', ')}${detail}`);
  }

  const propres = {};
  for (const champ of CHAMPS) {
    const valeur = donnees[champ];

    if (valeur === undefined) {
      if (complet) problemes.push(`"${champ}" est obligatoire`);
      continue;
    }

    if (typeof valeur !== 'string' || valeur.trim() === '') {
      problemes.push(`"${champ}" doit être une chaîne non vide`);
      continue;
    }

    propres[champ] = valeur.trim();
  }

  if (!complet && Object.keys(propres).length === 0 && problemes.length === 0) {
    problemes.push(`au moins un champ à modifier est requis (${CHAMPS.join(', ')})`);
  }

  if (problemes.length > 0) {
    throw new BadRequestError(`Données invalides : ${problemes.join(' ; ')}.`);
  }

  return propres;
}

/** Refuse un doublon (même nom dans la même ville), en ignorant le centre `idIgnore`. */
function verifierUnicite(nom, ville, idIgnore) {
  const existant = centreRepository.findByNomEtVille(nom, ville);
  if (existant && existant.id !== idIgnore) {
    throw new ConflictError(`Un centre nommé "${nom}" existe déjà à ${ville} (id ${existant.id}).`);
  }
}

/**
 * Liste des centres, filtrée par ville si `ville` est fourni.
 * @param {string|undefined} ville  undefined = pas de filtre ; '' ou '   ' = erreur 400
 */
function getCentres(ville) {
  if (ville === undefined) {
    return centreRepository.findAll();
  }

  if (ville.trim() === '') {
    throw new BadRequestError('Le paramètre "ville" ne doit pas être vide.');
  }

  return centreRepository.findByVille(ville);
}

function getCentreById(idBrut) {
  const id = parseId(idBrut);
  const centre = centreRepository.findById(id);

  if (!centre) {
    throw new NotFoundError(`Aucun centre avec l'identifiant ${id}.`);
  }

  return centre;
}

function createCentre(donnees) {
  const propres = valider(donnees, true);
  verifierUnicite(propres.nom, propres.ville);
  return centreRepository.create(propres);
}

/** PUT : remplacement complet. Le centre doit exister (pas de création via PUT). */
function replaceCentre(idBrut, donnees) {
  const id = parseId(idBrut);
  const propres = valider(donnees, true);

  if (!centreRepository.findById(id)) {
    throw new NotFoundError(`Aucun centre avec l'identifiant ${id}.`);
  }

  verifierUnicite(propres.nom, propres.ville, id);
  return centreRepository.update(id, propres);
}

/** PATCH : modification partielle. Seuls les champs fournis changent. */
function patchCentre(idBrut, donnees) {
  const id = parseId(idBrut);
  const modifs = valider(donnees, false);

  const actuel = centreRepository.findById(id);
  if (!actuel) {
    throw new NotFoundError(`Aucun centre avec l'identifiant ${id}.`);
  }

  const { id: _ignore, ...champsActuels } = actuel;
  const fusion = { ...champsActuels, ...modifs };

  verifierUnicite(fusion.nom, fusion.ville, id);
  return centreRepository.update(id, fusion);
}

function deleteCentre(idBrut) {
  const id = parseId(idBrut);

  if (!centreRepository.remove(id)) {
    throw new NotFoundError(`Aucun centre avec l'identifiant ${id}.`);
  }
}

module.exports = {
  getCentres,
  getCentreById,
  createCentre,
  replaceCentre,
  patchCentre,
  deleteCentre,
};
