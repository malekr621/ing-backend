#!/usr/bin/env bash
# Tests curl de l'API /api/centres
# Usage : démarrer le serveur (node src/server.js), puis : bash tests/curl-centres.sh
# Le script suppose un serveur fraîchement démarré (le centre créé reçoit l'id 6).

BASE="${BASE:-http://localhost:3000}"
JSON='Content-Type: application/json'

essai() {
  echo
  echo "################################################################"
  echo "# $1"
  echo "################################################################"
  shift
  # Affiche la commande avec ses guillemets (copiable dans un terminal)
  printf '$ curl'
  for a in "$@"; do
    case "$a" in
      *[\ \{\"]*) printf " '%s'" "$a" ;;
      *) printf ' %s' "$a" ;;
    esac
  done
  echo
  curl -s -i -w '\n' "$@"
}

essai "1. Liste de tous les centres (200)"                 "$BASE/api/centres"
essai "2. Un centre par id (200)"                          "$BASE/api/centres/1"
essai "3. Centre inexistant (404)"                         "$BASE/api/centres/999"
essai "4. Recherche par ville : Sousse (200)"              "$BASE/api/centres?ville=Sousse"
essai "5. Ville vide (400)"                                "$BASE/api/centres?ville="
essai "6. Identifiant invalide (400)"                      "$BASE/api/centres/abc"

essai "7. Création d'un centre (201 + Location)" \
  -X POST "$BASE/api/centres" -H "$JSON" \
  -d '{"nom":"Centre de Collecte de Bizerte","ville":"Bizerte","adresse":"14 Rue du Port","telephone":"72 000 006"}'
essai "8. Création avec champs manquants (400)" \
  -X POST "$BASE/api/centres" -H "$JSON" -d '{"nom":"Centre Incomplet"}'
essai "9. Création d'un doublon nom + ville (409)" \
  -X POST "$BASE/api/centres" -H "$JSON" \
  -d '{"nom":"Centre de Collecte de Bizerte","ville":"Bizerte","adresse":"autre adresse","telephone":"72 999 999"}'
essai "10. JSON invalide (400)" \
  -X POST "$BASE/api/centres" -H "$JSON" -d '{"nom": '

essai "11. Remplacement complet PUT (200)" \
  -X PUT "$BASE/api/centres/6" -H "$JSON" \
  -d '{"nom":"Centre Régional de Bizerte","ville":"Bizerte","adresse":"20 Avenue de la Mer","telephone":"72 000 060"}'
essai "12. PUT incomplet (400)" \
  -X PUT "$BASE/api/centres/6" -H "$JSON" -d '{"nom":"Seulement le nom"}'
essai "13. PUT sur un centre inexistant (404)" \
  -X PUT "$BASE/api/centres/999" -H "$JSON" \
  -d '{"nom":"X","ville":"Y","adresse":"Z","telephone":"1"}'

essai "14. Modification partielle PATCH (200)" \
  -X PATCH "$BASE/api/centres/6" -H "$JSON" -d '{"telephone":"72 111 111"}'
essai "15. PATCH avec un objet vide (400)" \
  -X PATCH "$BASE/api/centres/6" -H "$JSON" -d '{}'
essai "16. PATCH qui tente de changer l'id (400)" \
  -X PATCH "$BASE/api/centres/6" -H "$JSON" -d '{"id":99}'

essai "17. Suppression (204, sans corps)"                  -X DELETE "$BASE/api/centres/6"
essai "18. Le centre supprimé n'existe plus (404)"         "$BASE/api/centres/6"
essai "19. Méthode non autorisée sur la collection (405)"  -X DELETE "$BASE/api/centres"
essai "20. Méthode non autorisée sur une ressource (405)"  -X POST "$BASE/api/centres/1"
essai "21. Plusieurs routes à la suite" "$BASE/api/welcome" "$BASE/api/centres/2" "$BASE/api/donneurs/1"
