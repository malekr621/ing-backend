# SangConnect — API de gestion des dons de sang

API HTTP en Node.js pur (module `http`, sans dépendance externe).

## 1. Instructions de lancement

Prérequis : Node.js 18 ou plus récent.

```bash
node src/server.js
```

Le serveur écoute sur `http://localhost:3000`.

Options :

```bash
PORT=4000 NODE_ENV=production node src/server.js
```

## 2. Structure

```
sangconnect/
├── README.md
├── src/
│   ├── server.js                         # serveur, routes simples, 404 / 405
│   ├── routes/
│   │   ├── donneur.routes.js             # URL + méthode -> controller (donneurs)
│   │   └── centre.routes.js              # URL + méthode -> controller (centres)
│   ├── controllers/
│   │   ├── donneur.controller.js
│   │   └── centre.controller.js          # HTTP <-> service, corps JSON, codes de réponse
│   ├── services/
│   │   ├── donneur.service.js
│   │   └── centre.service.js             # validation, règles métier (doublons, 404)
│   ├── repositories/
│   │   ├── donneur.repository.js
│   │   └── centre.repository.js          # couche « Données » (tableau en mémoire)
│   └── utils/
│       ├── http.js                       # sendJson, sendNoContent, sendError, 404, 405
│       ├── errors.js                     # AppError, NotFound, BadRequest, Conflict, PayloadTooLarge
│       └── body.js                       # readJsonBody() : lecture du corps JSON
├── tests/
│   └── curl-centres.sh                   # 21 tests curl
└── docs/
    └── resultats-curl-centres.txt        # sortie réelle du script de tests
```

## 3. Routes et méthodes acceptées

| Route             | Méthodes acceptées | Description                                              |
|-------------------|--------------------|----------------------------------------------------------|
| `/api/welcome`    | `GET`              | Message de bienvenue                                     |
| `/api/version`    | `GET`              | Nom de l'application, version API, version Node, environnement |
| `/api/diagnostic` | `GET`              | Méthode, URL, date et en-têtes de la requête             |
| `/api/donneurs`   | `GET`              | Liste des donneurs (filtre optionnel `?ville=Tunis`)     |
| `/api/donneurs/:id` | `GET`            | Un donneur par identifiant                               |
| `/api/centres`    | `GET`, `POST`      | Liste des centres (filtre `?ville=`) / création          |
| `/api/centres/:id` | `GET`, `PUT`, `PATCH`, `DELETE` | Lire / remplacer / modifier partiellement / supprimer |
| *(autre route)*   | —                  | Réponse 404 en JSON                                      |

## 4. Codes de statut utilisés

| Code | Signification        | Quand ?                                              |
|------|----------------------|------------------------------------------------------|
| 200  | OK                   | Route existante appelée avec une méthode autorisée   |
| 404  | Not Found            | Route non définie                                    |
| 405  | Method Not Allowed   | Route existante, méthode non autorisée (en-tête `Allow` ajouté) |
| 201  | Created              | Création d'un centre (en-tête `Location` ajouté)     |
| 204  | No Content           | Suppression réussie (réponse sans corps)             |
| 409  | Conflict             | Centre de même nom déjà présent dans la même ville   |
| 413  | Payload Too Large    | Corps de requête supérieur à 1 Mo                    |
| 400  | Bad Request          | `?ville=` vide, ou identifiant non numérique (`/api/donneurs/abc`) |
| 500  | Internal Server Error | Erreur inattendue (ex. repository en panne), détails masqués au client |

## 5. Commandes curl (tests)

Route existante avec `GET` :

```bash
curl -i http://localhost:3000/api/welcome
curl -i http://localhost:3000/api/version
curl -i http://localhost:3000/api/diagnostic
```

Route inexistante (404) :

```bash
curl -i http://localhost:3000/api/inconnue
```

Route existante avec méthode non autorisée (405) :

```bash
curl -i -X POST   http://localhost:3000/api/diagnostic
curl -i -X DELETE http://localhost:3000/api/welcome
```

Plusieurs routes à la suite :

```bash
curl -i http://localhost:3000/api/welcome http://localhost:3000/api/version http://localhost:3000/api/inconnue
```

### Exemples de réponses

`GET /api/welcome` → `200`

```json
{
  "message": "Bienvenue dans l’API SangConnect",
  "description": "Gestion des dons de sang"
}
```

`POST /api/diagnostic` → `405` (en-tête `Allow: GET`)

```json
{
  "error": "Méthode non autorisée",
  "message": "La méthode POST n'est pas autorisée sur /api/diagnostic. Utilisez : GET.",
  "path": "/api/diagnostic",
  "method": "POST",
  "allowedMethods": ["GET"]
}
```

`GET /api/inconnue` → `404`

```json
{
  "error": "Route non trouvée",
  "path": "/api/inconnue",
  "method": "GET",
  "timestamp": "2026-11-08T10:00:00.000Z"
}
```

## 6. Explication de `sendJson()`

```js
sendJson(res, statusCode, data, headers = {})
```

Cette fonction centralise l'envoi des réponses JSON afin d'éviter de répéter le même code dans chaque route :

1. `JSON.stringify(data, null, 2)` convertit l'objet JavaScript en texte JSON lisible.
2. `res.writeHead(statusCode, {...})` envoie le code de statut et les en-têtes :
   - `Content-Type: application/json; charset=utf-8` indique au client que le corps est du JSON (UTF-8, pour les accents) ;
   - `Content-Length` donne la taille exacte du corps en octets (`Buffer.byteLength`, car un caractère accentué fait plus d'un octet) ;
   - `headers` permet d'ajouter des en-têtes propres à un cas, par exemple `Allow` pour un 405.
3. `res.end(body)` envoie le corps et termine la réponse.

`sendMethodNotAllowed()` et `sendNotFound()` s'appuient sur `sendJson()` pour produire les réponses 405 et 404.

---

## 7. Gestion des donneurs : architecture en couches

Une requête traverse quatre couches. Chaque couche n'appelle que celle située juste en dessous.

```
Requête HTTP
   │
   ▼
routes/donneur.routes.js        Quelle URL ? Quelle méthode ? -> choisit le controller
   │
   ▼
controllers/donneur.controller  Lit la requête (id, ?ville), appelle le service,
   │                            écrit la réponse JSON, convertit les erreurs en codes HTTP
   ▼
services/donneur.service        Règles métier : validation (ville vide, id invalide),
   │                            donneur introuvable -> NotFoundError
   ▼
repositories/donneur.repository Accès aux données : findAll, findById, findByVille
                                (tableau en mémoire, données fictives)
```

### Rôle de chaque couche

| Couche      | Responsabilité                                             | Ne doit PAS                          |
|-------------|------------------------------------------------------------|--------------------------------------|
| Routes      | Associer URL + méthode à une fonction du controller        | Contenir de la logique               |
| Controller  | Traduire HTTP <-> appels de service ; erreurs -> codes HTTP | Accéder aux données, valider le métier |
| Service     | Validation et règles métier ; lever des erreurs typées     | Connaître `req` / `res`              |
| Repository  | Lire les données                                           | Connaître HTTP ou les règles métier  |

**Avantage :** remplacer le tableau par une vraie base de données ne change que le repository ; les autres couches restent intactes.

### Où se fait la recherche par ville ?

- La **validation** (ville vide -> 400) est dans le **service**, car c'est une règle métier.
- Le **filtrage** est dans le **repository** (`findByVille`), car c'est une opération sur les données. La comparaison ignore la casse et les accents (`tunis`, `TUNIS` et `Tunis` donnent le même résultat).
- Le **controller** se contente de lire `?ville=` et de transmettre la valeur.

### Données fictives

Six donneurs sont définis dans `src/repositories/donneur.repository.js` (id 1 à 6), au format :

```js
{ id: 1, nom: "Ben Ali", prenom: "Ahmed", groupeSanguin: "O+", ville: "Tunis" }
```

### Gestion des erreurs

| Situation              | Où elle est détectée | Réponse |
|------------------------|----------------------|---------|
| Donneur inexistant     | service (`NotFoundError`)    | 404 |
| Ville vide             | service (`BadRequestError`)  | 400 |
| Id non numérique       | service (`BadRequestError`)  | 400 |
| Erreur du repository   | repository (`Error`), interceptée par le controller | 500 (message générique, détail dans la console du serveur) |

Corps d'erreur type :

```json
{ "error": "Ressource non trouvée", "message": "Aucun donneur avec l'identifiant 999.", "status": 404 }
```

Pour simuler une panne du repository :

```bash
SIMULATE_REPO_ERROR=true node src/server.js
```

## 8. Tests curl : donneurs

```bash
# Liste des donneurs -> 200
curl -i http://localhost:3000/api/donneurs

# Un donneur -> 200
curl -i http://localhost:3000/api/donneurs/1

# Donneur inexistant -> 404
curl -i http://localhost:3000/api/donneurs/999

# Recherche par ville -> 200 (Ahmed et Leila)
curl -i "http://localhost:3000/api/donneurs?ville=Tunis"

# Ville vide -> 400
curl -i "http://localhost:3000/api/donneurs?ville="

# Identifiant invalide -> 400
curl -i http://localhost:3000/api/donneurs/abc

# Méthode non autorisée -> 405 (en-tête Allow: GET)
curl -i -X POST http://localhost:3000/api/donneurs

# Erreur simulée du repository -> 500 (relancer le serveur avec SIMULATE_REPO_ERROR=true)
curl -i http://localhost:3000/api/donneurs
```

---

## 9. API REST des centres de collecte

### Modèle

```json
{ "id": 1, "nom": "Centre de Transfusion de Tunis", "ville": "Tunis",
  "adresse": "12 Rue de la Santé", "telephone": "71 000 001" }
```

Cinq centres fictifs sont définis dans `src/repositories/centre.repository.js`. Les modifications sont conservées en mémoire : elles disparaissent à l'arrêt du serveur.

### Routes REST

| Méthode  | Route                          | Rôle                                   | Succès | Erreurs possibles   |
|----------|--------------------------------|----------------------------------------|--------|---------------------|
| `GET`    | `/api/centres`                 | Lister les centres                     | 200    | 500                 |
| `GET`    | `/api/centres?ville=Sousse`    | Centres d'une ville                    | 200    | 400 (ville vide)    |
| `GET`    | `/api/centres/:id`             | Lire un centre                         | 200    | 400, 404            |
| `POST`   | `/api/centres`                 | Créer un centre                        | 201    | 400, 409, 413       |
| `PUT`    | `/api/centres/:id`             | Remplacer un centre (4 champs requis)  | 200    | 400, 404, 409       |
| `PATCH`  | `/api/centres/:id`             | Modifier certains champs               | 200    | 400, 404, 409       |
| `DELETE` | `/api/centres/:id`             | Supprimer un centre                    | 204    | 400, 404            |
| autre    | `/api/centres`, `/api/centres/:id` | méthode non prévue                 | —      | 405 + en-tête `Allow` |

Règles de validation (dans le service) :
- `POST` et `PUT` : `nom`, `ville`, `adresse`, `telephone` obligatoires, chaînes non vides.
- `PATCH` : au moins un de ces champs ; seuls les champs envoyés changent.
- Tout autre champ est refusé, y compris `id` (l'identifiant n'est pas modifiable).
- `PUT` sur un id inexistant donne 404 : il ne crée pas de centre.
- Deux centres ne peuvent pas avoir le même nom dans la même ville (409).

### Architecture retenue

```
Requête HTTP
   │
   ▼
routes/centre.routes.js          Aiguillage : (URL, méthode) -> fonction du controller
   │                             405 si la méthode n'existe pas pour cette URL
   ▼
controllers/centre.controller    Lit id, ?ville, corps JSON ; appelle le service ;
   │                             écrit la réponse (200, 201, 204) ; sendError() pour les erreurs
   ▼
services/centre.service          Validation, règles métier (doublons, 404, PUT vs PATCH)
   │                             Lève NotFoundError, BadRequestError, ConflictError
   ▼
repositories/centre.repository   Données : findAll, findById, findByVille, create, update, remove
```

| Couche      | Responsabilité                                   | Ne doit pas                         |
|-------------|--------------------------------------------------|-------------------------------------|
| Routes      | Choisir la bonne fonction selon URL + méthode    | Contenir de la logique              |
| Controller  | Traduire HTTP <-> appels de service              | Valider le métier, toucher aux données |
| Service     | Valider, appliquer les règles métier             | Connaître `req` / `res`             |
| Données     | Lire / écrire                                    | Connaître HTTP ou les règles métier |

La recherche par ville suit le même principe que pour les donneurs : la validation (ville vide) est dans le service, le filtrage dans la couche données.

### Question de réflexion

**Pourquoi séparer Routes, Controllers et Services plutôt que tout mettre dans `server.js` ?**

1. **Une responsabilité par fichier.** Quand une route ne répond pas comme prévu, on sait où chercher : mauvaise URL ou méthode -> routes ; mauvais code HTTP -> controller ; mauvaise règle (doublon, validation) -> service. Dans un seul fichier, ces trois préoccupations s'entremêlent.
2. **Lisibilité et travail en équipe.** `server.js` grossit à chaque ressource (donneurs, centres, puis dons, rendez-vous...). Séparé, il reste court : il démarre le serveur et branche les routes. Deux personnes peuvent travailler sur deux ressources sans se marcher dessus.
3. **Réutilisation.** La logique métier du service ne dépend pas de HTTP. On peut l'appeler depuis un autre point d'entrée (script, tâche planifiée, autre API) sans copier de code.
4. **Testabilité.** Un service se teste en appelant une fonction avec des données, sans démarrer de serveur ni simuler `req` et `res`.
5. **Évolutivité.** Changer la source de données (tableau en mémoire -> base de données) ne touche que la couche données. Passer de `http` à Express ne touche que les routes et les controllers.
6. **Moins de duplication.** Règles de validation et gestion d'erreurs sont écrites une fois (`sendError`, `AppError`), pas recopiées dans chaque route.

Le coût : davantage de fichiers et un peu plus de code d'assemblage pour un petit projet. Il se rentabilise dès que l'application dépasse une ou deux ressources.

### Tests curl

Démarrer un serveur neuf puis lancer les 21 tests :

```bash
node src/server.js
# dans un autre terminal :
bash tests/curl-centres.sh
```

La sortie complète d'une exécution réelle est dans `docs/resultats-curl-centres.txt`.

Exemples :

```bash
# Liste, un centre, centre inexistant, recherche par ville
curl -i http://localhost:3000/api/centres
curl -i http://localhost:3000/api/centres/1
curl -i http://localhost:3000/api/centres/999
curl -i "http://localhost:3000/api/centres?ville=Sousse"

# Création -> 201
curl -i -X POST http://localhost:3000/api/centres \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre de Collecte de Bizerte","ville":"Bizerte","adresse":"14 Rue du Port","telephone":"72 000 006"}'

# Remplacement complet -> 200
curl -i -X PUT http://localhost:3000/api/centres/6 \
  -H "Content-Type: application/json" \
  -d '{"nom":"Centre Régional de Bizerte","ville":"Bizerte","adresse":"20 Avenue de la Mer","telephone":"72 000 060"}'

# Modification partielle -> 200
curl -i -X PATCH http://localhost:3000/api/centres/6 \
  -H "Content-Type: application/json" \
  -d '{"telephone":"72 111 111"}'

# Suppression -> 204
curl -i -X DELETE http://localhost:3000/api/centres/6
```

> Sous Windows (PowerShell), utilisez `curl.exe` à la place de `curl`, et remplacez les `\` de fin de ligne par un accent grave `` ` ``. Pour le JSON, préférez des guillemets simples autour du corps et échappez les guillemets doubles, ou utilisez Git Bash.

### Captures d'écran

Le sujet demande quelques captures d'écran. Elles doivent être prises sur votre machine : lancez le serveur puis `bash tests/curl-centres.sh`, et capturez au minimum les tests 1 (liste), 4 (recherche par ville), 7 (création 201), 14 (PATCH), 17 (suppression 204) et 19 (méthode non autorisée 405).
