'use strict';

const centreController = require('../controllers/centre.controller');
const { sendMethodNotAllowed } = require('../utils/http');

/**
 * Couche ROUTES : associe (URL + méthode HTTP) à une fonction du controller.
 * Aucune logique ici : uniquement de l'aiguillage.
 */

/** Décode un segment d'URL sans planter si l'encodage est invalide (ex. %E0%A4%A). */
function decoderSegment(segment) {
  try {
    return decodeURIComponent(segment);
  } catch {
    return segment;
  }
}

// /api/centres
const COLLECTION = {
  GET: (req, res, _id, searchParams) => centreController.getAll(req, res, searchParams),
  POST: (req, res) => centreController.create(req, res),
};

// /api/centres/:id
const RESSOURCE = {
  GET: (req, res, id) => centreController.getById(req, res, id),
  PUT: (req, res, id) => centreController.replace(req, res, id),
  PATCH: (req, res, id) => centreController.patch(req, res, id),
  DELETE: (req, res, id) => centreController.remove(req, res, id),
};

/**
 * @returns {boolean} true si la requête a été prise en charge, false sinon
 *                    (le serveur poursuit alors avec les autres routes / le 404).
 */
function handleCentreRoutes(req, res, pathname, searchParams) {
  let table;
  let id;

  if (/^\/api\/centres\/?$/.test(pathname)) {
    table = COLLECTION;
  } else {
    const match = pathname.match(/^\/api\/centres\/([^/]+)\/?$/);
    if (!match) return false;
    table = RESSOURCE;
    id = decoderSegment(match[1]);
  }

  const action = table[req.method];
  if (!action) {
    sendMethodNotAllowed(req, res, pathname, Object.keys(table));
  } else {
    action(req, res, id, searchParams);
  }
  return true;
}

module.exports = { handleCentreRoutes };
