'use strict';

/**
 * Couche DONNÉES : seul endroit qui connaît la source des données.
 * Ici, un tableau en mémoire (données entièrement fictives).
 * Les modifications sont perdues à l'arrêt du serveur.
 */
const centres = [
  { id: 1, nom: 'Centre de Transfusion de Tunis', ville: 'Tunis', adresse: '12 Rue de la Santé', telephone: '71 000 001' },
  { id: 2, nom: 'Centre Régional de Sousse', ville: 'Sousse', adresse: '5 Avenue de la Corniche', telephone: '73 000 002' },
  { id: 3, nom: 'Centre de Collecte de Sfax', ville: 'Sfax', adresse: '8 Rue des Oliviers', telephone: '74 000 003' },
  { id: 4, nom: 'Centre Don de Vie Tunis Nord', ville: 'Tunis', adresse: '27 Avenue du Lac', telephone: '71 000 004' },
  { id: 5, nom: 'Centre de Collecte Sousse Médina', ville: 'Sousse', adresse: '3 Rue de la Médina', telephone: '73 000 005' },
];

let prochainId = 6;

/** Compare sans tenir compte de la casse ni des accents. */
function normaliser(texte) {
  return String(texte)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Simule une panne de la source de données.
 * Activer avec : SIMULATE_REPO_ERROR=true node src/server.js
 */
function verifierDisponibilite() {
  if (process.env.SIMULATE_REPO_ERROR === 'true') {
    throw new Error('Erreur simulée : source de données indisponible');
  }
}

function findAll() {
  verifierDisponibilite();
  return centres.map((c) => ({ ...c }));
}

function findById(id) {
  verifierDisponibilite();
  const centre = centres.find((c) => c.id === id);
  return centre ? { ...centre } : null;
}

function findByVille(ville) {
  verifierDisponibilite();
  const cible = normaliser(ville);
  return centres.filter((c) => normaliser(c.ville) === cible).map((c) => ({ ...c }));
}

/** Cherche un centre de même nom dans la même ville (pour détecter les doublons). */
function findByNomEtVille(nom, ville) {
  verifierDisponibilite();
  const centre = centres.find(
    (c) => normaliser(c.nom) === normaliser(nom) && normaliser(c.ville) === normaliser(ville)
  );
  return centre ? { ...centre } : null;
}

function create(donnees) {
  verifierDisponibilite();
  const centre = { id: prochainId++, ...donnees };
  centres.push(centre);
  return { ...centre };
}

/** Remplace les champs d'un centre. Retourne le centre modifié, ou null s'il n'existe pas. */
function update(id, donnees) {
  verifierDisponibilite();
  const index = centres.findIndex((c) => c.id === id);
  if (index === -1) return null;
  centres[index] = { id, ...donnees };
  return { ...centres[index] };
}

/** Supprime un centre. Retourne true si supprimé, false s'il n'existait pas. */
function remove(id) {
  verifierDisponibilite();
  const index = centres.findIndex((c) => c.id === id);
  if (index === -1) return false;
  centres.splice(index, 1);
  return true;
}

module.exports = { findAll, findById, findByVille, findByNomEtVille, create, update, remove };
