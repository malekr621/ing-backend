'use strict';

const { BadRequestError, PayloadTooLargeError } = require('./errors');

const MAX_BYTES = 1024 * 1024; // 1 Mo

/**
 * Lit et parse le corps JSON d'une requête (POST, PUT, PATCH).
 * @returns {Promise<object>} objet JSON
 * @throws {BadRequestError}      corps vide, JSON invalide ou pas un objet
 * @throws {PayloadTooLargeError} corps supérieur à 1 Mo
 */
function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let taille = 0;
    let trop = false;

    req.on('data', (chunk) => {
      if (trop) return;
      taille += chunk.length;
      if (taille > MAX_BYTES) {
        trop = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      if (trop) {
        return reject(new PayloadTooLargeError('Le corps de la requête dépasse 1 Mo.'));
      }

      const texte = Buffer.concat(chunks).toString('utf-8').trim();
      if (texte === '') {
        return reject(new BadRequestError('Le corps de la requête est vide : un objet JSON est attendu.'));
      }

      let donnees;
      try {
        donnees = JSON.parse(texte);
      } catch {
        return reject(new BadRequestError('Le corps de la requête n\'est pas un JSON valide.'));
      }

      if (donnees === null || typeof donnees !== 'object' || Array.isArray(donnees)) {
        return reject(new BadRequestError('Le corps de la requête doit être un objet JSON.'));
      }

      resolve(donnees);
    });

    req.on('error', reject);
  });
}

module.exports = { readJsonBody };
