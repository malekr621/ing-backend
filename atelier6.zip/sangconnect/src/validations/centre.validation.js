import { z } from "zod";

export const createCentreSchema = z.object({
  nom: z.string().trim().min(1),
  ville: z.string().trim().min(1)
});
