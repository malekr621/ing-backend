import { z } from "zod";

const GROUPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

const volume = z.coerce.number().int().min(100).max(1000);
const id = z.coerce.number().int().positive();

export const createDonSchema = z.object({
  volume,
  donneurId: id,
  centreId: id,
  dateDon: z.coerce.date().optional()
});

// PUT : remplacement complet
export const updateDonSchema = createDonSchema;

// PATCH : modification partielle (au moins un champ)
export const patchDonSchema = createDonSchema
  .partial()
  .refine((data) => Object.keys(data).length > 0, {
    message: "Au moins un champ est requis"
  });

export const listDonsQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
  centreId: id.optional(),
  donneurId: id.optional(),
  ville: z.string().trim().min(1).optional(),
  // Dans une URL, "+" est decode en espace : "A+" arrive donc sous la forme "A ".
  // On remet le "+" avant de valider (ou utiliser ?groupeSanguin=A%2B).
  groupeSanguin: z
    .string()
    .transform((v) => v.replace(/ /g, "+").trim().toUpperCase())
    .pipe(z.enum(GROUPES, { message: `Groupe sanguin invalide (${GROUPES.join(", ")})` }))
    .optional(),
  sortBy: z.enum(["dateDon", "volume"]).default("dateDon"),
  order: z.enum(["asc", "desc"]).default("desc")
});
