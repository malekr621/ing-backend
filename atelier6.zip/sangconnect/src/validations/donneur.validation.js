import { z } from "zod";

export const createDonneurSchema = z.object({
  nom: z.string().trim().min(1),
  prenom: z.string().trim().min(1),
  groupeSanguin: z.enum(["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]),
  telephone: z.string().trim().min(1).optional()
});
