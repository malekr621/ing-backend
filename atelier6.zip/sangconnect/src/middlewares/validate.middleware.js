import { httpError } from "../utils/httpError.js";

// Valide req.body / req.query / req.params avec un schema Zod.
// Le resultat valide est place dans req.validated[source].
export function validate(schema, source = "body") {
  return (req, res, next) => {
    const result = schema.safeParse(req[source]);

    if (!result.success) {
      const error = httpError(400, "Données invalides");
      error.details = result.error.issues.map((issue) => ({
        champ: issue.path.join("."),
        message: issue.message
      }));
      return next(error);
    }

    req.validated = { ...req.validated, [source]: result.data };
    next();
  };
}
