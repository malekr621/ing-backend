export function notFound(req, res) {
  res.status(404).json({ message: `Route introuvable : ${req.method} ${req.originalUrl}` });
}

export function errorHandler(error, req, res, next) {
  // Erreurs Prisma courantes
  if (error.code === "P2025") {
    return res.status(404).json({ message: "Ressource introuvable" });
  }
  if (error.code === "P2003") {
    return res.status(400).json({ message: "Référence invalide ou ressource liée existante" });
  }

  const statusCode = error.statusCode || 500;

  if (statusCode === 500) {
    console.error(error);
  }

  res.status(statusCode).json({
    message: statusCode === 500 ? "Erreur interne du serveur" : error.message,
    ...(error.details && { details: error.details })
  });
}
