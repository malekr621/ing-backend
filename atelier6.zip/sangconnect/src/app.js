import express from "express";
import donRoutes from "./routes/don.routes.js";
import donneurRoutes from "./routes/donneur.routes.js";
import centreRoutes from "./routes/centre.routes.js";
import { notFound, errorHandler } from "./middlewares/error.middleware.js";

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
  res.json({ message: "SangConnect API", version: "1.0.0" });
});

app.use("/api/dons", donRoutes);
app.use("/api/donneurs", donneurRoutes);
app.use("/api/centres", centreRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;
