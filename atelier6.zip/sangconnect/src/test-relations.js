// Script de test des requetes de l'atelier : node src/test-relations.js
import prisma from "./database/prisma.js";

console.log("1) Dons avec donneur et centre (include)");
console.log(await prisma.don.findMany({ include: { donneur: true, centre: true } }));

console.log("2) Dons du groupe A+ a Sousse, du plus recent au plus ancien");
console.log(
  await prisma.don.findMany({
    where: { donneur: { groupeSanguin: "A+" }, centre: { ville: "Sousse" } },
    orderBy: { dateDon: "desc" },
    select: {
      id: true,
      dateDon: true,
      volume: true,
      donneur: { select: { nom: true, prenom: true } },
      centre: { select: { nom: true } }
    }
  })
);

console.log("3) Donneurs avec leurs dons (evite le probleme N+1)");
console.log(await prisma.donneur.findMany({ include: { dons: true } }));

await prisma.$disconnect();
