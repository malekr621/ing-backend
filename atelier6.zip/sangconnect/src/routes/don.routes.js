import express from "express";
import * as controller from "../controllers/don.controller.js";
import { validate } from "../middlewares/validate.middleware.js";
import { idParamSchema } from "../validations/common.validation.js";
import {
  createDonSchema,
  updateDonSchema,
  patchDonSchema,
  listDonsQuerySchema
} from "../validations/don.validation.js";

const router = express.Router();

router.get("/", validate(listDonsQuerySchema, "query"), controller.getAll);
router.get("/:id", validate(idParamSchema, "params"), controller.getById);
router.post("/", validate(createDonSchema), controller.create);
router.put("/:id", validate(idParamSchema, "params"), validate(updateDonSchema), controller.update);
router.patch("/:id", validate(idParamSchema, "params"), validate(patchDonSchema), controller.update);
router.delete("/:id", validate(idParamSchema, "params"), controller.remove);

export default router;
