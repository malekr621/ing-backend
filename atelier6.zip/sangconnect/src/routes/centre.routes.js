import express from "express";
import * as controller from "../controllers/centre.controller.js";
import { validate } from "../middlewares/validate.middleware.js";
import { idParamSchema } from "../validations/common.validation.js";
import { createCentreSchema } from "../validations/centre.validation.js";

const router = express.Router();

router.get("/", controller.getAll);
router.get("/:id", validate(idParamSchema, "params"), controller.getById);
router.post("/", validate(createCentreSchema), controller.create);

export default router;
