import express from "express";
import * as controller from "../controllers/donneur.controller.js";
import { validate } from "../middlewares/validate.middleware.js";
import { idParamSchema } from "../validations/common.validation.js";
import { createDonneurSchema } from "../validations/donneur.validation.js";

const router = express.Router();

router.get("/", controller.getAll);
router.get("/:id", validate(idParamSchema, "params"), controller.getById);
router.get("/:id/dons", validate(idParamSchema, "params"), controller.getDons);
router.post("/", validate(createDonneurSchema), controller.create);

export default router;
