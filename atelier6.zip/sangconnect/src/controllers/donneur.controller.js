import * as donneurService from "../services/donneur.service.js";
import * as donService from "../services/don.service.js";

export async function getAll(req, res, next) {
  try {
    res.json(await donneurService.getAll());
  } catch (error) {
    next(error);
  }
}

export async function getById(req, res, next) {
  try {
    res.json(await donneurService.getById(req.validated.params.id));
  } catch (error) {
    next(error);
  }
}

export async function create(req, res, next) {
  try {
    res.status(201).json(await donneurService.create(req.validated.body));
  } catch (error) {
    next(error);
  }
}

// GET /api/donneurs/:id/dons
export async function getDons(req, res, next) {
  try {
    res.json(await donService.getByDonneur(req.validated.params.id));
  } catch (error) {
    next(error);
  }
}
