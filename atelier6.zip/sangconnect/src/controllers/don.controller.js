import * as donService from "../services/don.service.js";

export async function getAll(req, res, next) {
  try {
    res.json(await donService.getAll(req.validated.query));
  } catch (error) {
    next(error);
  }
}

export async function getById(req, res, next) {
  try {
    res.json(await donService.getById(req.validated.params.id));
  } catch (error) {
    next(error);
  }
}

export async function create(req, res, next) {
  try {
    const don = await donService.create(req.validated.body);
    res.status(201).json(don);
  } catch (error) {
    next(error);
  }
}

export async function update(req, res, next) {
  try {
    res.json(await donService.update(req.validated.params.id, req.validated.body));
  } catch (error) {
    next(error);
  }
}

export async function remove(req, res, next) {
  try {
    await donService.remove(req.validated.params.id);
    res.status(204).send();
  } catch (error) {
    next(error);
  }
}
