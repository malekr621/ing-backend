import * as centreService from "../services/centre.service.js";

export async function getAll(req, res, next) {
  try {
    res.json(await centreService.getAll());
  } catch (error) {
    next(error);
  }
}

export async function getById(req, res, next) {
  try {
    res.json(await centreService.getById(req.validated.params.id));
  } catch (error) {
    next(error);
  }
}

export async function create(req, res, next) {
  try {
    res.status(201).json(await centreService.create(req.validated.body));
  } catch (error) {
    next(error);
  }
}
