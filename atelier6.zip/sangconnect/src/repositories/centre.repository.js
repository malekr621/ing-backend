import prisma from "../database/prisma.js";

export function findAll() {
  return prisma.centre.findMany({ orderBy: { id: "asc" } });
}

export function findById(id) {
  return prisma.centre.findUnique({ where: { id } });
}

export function create(data) {
  return prisma.centre.create({ data });
}
