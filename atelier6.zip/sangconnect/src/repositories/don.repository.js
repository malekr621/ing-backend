import prisma from "../database/prisma.js";

// Champs retournes : uniquement le necessaire (select plutot que include)
const donSelect = {
  id: true,
  dateDon: true,
  volume: true,
  donneur: {
    select: { id: true, nom: true, prenom: true, groupeSanguin: true }
  },
  centre: {
    select: { id: true, nom: true, ville: true }
  }
};

// Liste filtree + triee + paginee, avec le total (meme "where" pour les deux)
export async function findAndCount({ where, orderBy, skip, take }) {
  const [data, total] = await prisma.$transaction([
    prisma.don.findMany({ where, orderBy, skip, take, select: donSelect }),
    prisma.don.count({ where })
  ]);

  return { data, total };
}

export function findById(id) {
  return prisma.don.findUnique({
    where: { id },
    select: donSelect
  });
}

export function findByDonneur(donneurId) {
  return prisma.don.findMany({
    where: { donneurId },
    select: {
      id: true,
      dateDon: true,
      volume: true,
      centre: { select: { id: true, nom: true, ville: true } }
    },
    orderBy: { dateDon: "desc" }
  });
}

export function create(data) {
  return prisma.don.create({ data, select: donSelect });
}

export function update(id, data) {
  return prisma.don.update({ where: { id }, data, select: donSelect });
}

export function remove(id) {
  return prisma.don.delete({ where: { id } });
}
