import prisma from "../database/prisma.js";

export function findAll() {
  return prisma.donneur.findMany({ orderBy: { id: "asc" } });
}

export function findById(id) {
  return prisma.donneur.findUnique({ where: { id } });
}

// Donneur avec ses dons : un seul appel, pas de N+1
export function findWithDons(id) {
  return prisma.donneur.findUnique({
    where: { id },
    include: {
      dons: {
        orderBy: { dateDon: "desc" },
        include: { centre: { select: { id: true, nom: true, ville: true } } }
      }
    }
  });
}

export function create(data) {
  return prisma.donneur.create({ data });
}
