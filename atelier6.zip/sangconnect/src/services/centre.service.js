import * as centreRepository from "../repositories/centre.repository.js";
import { httpError } from "../utils/httpError.js";

export function getAll() {
  return centreRepository.findAll();
}

export async function getById(id) {
  const centre = await centreRepository.findById(id);

  if (!centre) {
    throw httpError(404, "Centre introuvable");
  }

  return centre;
}

export function create(data) {
  return centreRepository.create(data);
}
