import * as donRepository from "../repositories/don.repository.js";
import * as donneurRepository from "../repositories/donneur.repository.js";
import * as centreRepository from "../repositories/centre.repository.js";
import { httpError } from "../utils/httpError.js";

export async function getAll(query) {
  const { page, limit, centreId, donneurId, ville, groupeSanguin, sortBy, order } = query;

  // Construction du "where" a partir des filtres presents
  const where = {};
  if (centreId) where.centreId = centreId;
  if (donneurId) where.donneurId = donneurId;
  if (ville) where.centre = { ville };
  if (groupeSanguin) where.donneur = { groupeSanguin };

  const { data, total } = await donRepository.findAndCount({
    where,
    orderBy: { [sortBy]: order },
    skip: (page - 1) * limit,
    take: limit
  });

  return {
    data,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
}

export async function getById(id) {
  const don = await donRepository.findById(id);

  if (!don) {
    throw httpError(404, "Don introuvable");
  }

  return don;
}

export async function getByDonneur(donneurId) {
  const donneur = await donneurRepository.findById(donneurId);

  if (!donneur) {
    throw httpError(404, "Donneur introuvable");
  }

  return donRepository.findByDonneur(donneurId);
}

// Verifie que le donneur et le centre references existent
async function checkReferences({ donneurId, centreId }) {
  if (donneurId !== undefined && !(await donneurRepository.findById(donneurId))) {
    throw httpError(404, "Donneur introuvable");
  }
  if (centreId !== undefined && !(await centreRepository.findById(centreId))) {
    throw httpError(404, "Centre introuvable");
  }
}

export async function create(data) {
  await checkReferences(data);
  return donRepository.create(data);
}

export async function update(id, data) {
  await getById(id);
  await checkReferences(data);
  return donRepository.update(id, data);
}

export async function remove(id) {
  await getById(id);
  await donRepository.remove(id);
}
