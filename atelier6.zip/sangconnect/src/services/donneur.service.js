import * as donneurRepository from "../repositories/donneur.repository.js";
import { httpError } from "../utils/httpError.js";

export function getAll() {
  return donneurRepository.findAll();
}

export async function getById(id) {
  const donneur = await donneurRepository.findWithDons(id);

  if (!donneur) {
    throw httpError(404, "Donneur introuvable");
  }

  return donneur;
}

export function create(data) {
  return donneurRepository.create(data);
}
