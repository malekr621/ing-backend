# SangConnect — API de gestion des dons de sang

Projet fil rouge (Atelier 6) : relations Prisma `Donneur 1-N Don N-1 Centre`,
`include` / `select`, filtres, tri, pagination et architecture en couches.

**Stack :** Node.js · Express · Zod · Prisma ORM · MySQL

## Architecture

```
Route → Validation (Zod) → Controller → Service → Repository → Prisma → MySQL
```

```
prisma/
  schema.prisma          modèles Donneur, Centre, Don
  seed.js                jeu de données de test
src/
  server.js / app.js     démarrage et configuration Express
  database/prisma.js     PrismaClient
  routes/                URL
  validations/           schémas Zod
  controllers/           gestion HTTP
  services/              logique métier
  repositories/          requêtes Prisma
  middlewares/           validation, erreurs
  test-relations.js      script de test des requêtes de l'atelier
```

## Installation

```bash
npm install
cp .env.example .env        # puis adapter DATABASE_URL
```

Créer la base MySQL :

```sql
CREATE DATABASE sangconnect;
CREATE USER 'sangconnect'@'localhost' IDENTIFIED BY 'motdepasse';
GRANT ALL PRIVILEGES ON *.* TO 'sangconnect'@'localhost';
FLUSH PRIVILEGES;
```

> Prisma a besoin de droits étendus pour créer la base « shadow » utilisée par `migrate dev`.

Migration, génération du client et données de test :

```bash
npx prisma migrate dev --name add_dons_centres
npx prisma generate
npm run seed
```

Démarrer le serveur :

```bash
npm run dev
```

## Routes

| Méthode | URL | Description |
|---|---|---|
| GET | `/api/dons` | Liste (filtres, tri, pagination) |
| GET | `/api/dons/:id` | Détail d'un don (avec donneur et centre) |
| POST | `/api/dons` | Créer un don |
| PUT | `/api/dons/:id` | Remplacer un don |
| PATCH | `/api/dons/:id` | Modifier partiellement un don |
| DELETE | `/api/dons/:id` | Supprimer un don |
| GET | `/api/donneurs` · `/api/donneurs/:id` · `/api/donneurs/:id/dons` | Donneurs et leurs dons |
| POST | `/api/donneurs` | Créer un donneur |
| GET / POST | `/api/centres` · `/api/centres/:id` | Centres |

### Paramètres de `GET /api/dons`

| Paramètre | Exemple | Défaut |
|---|---|---|
| `page`, `limit` | `?page=2&limit=10` | 1, 10 (max 100) |
| `centreId` | `?centreId=1` | |
| `donneurId` | `?donneurId=2` | |
| `ville` | `?ville=Sousse` | |
| `groupeSanguin` | `?groupeSanguin=A%2B` | |
| `sortBy` | `dateDon` ou `volume` | `dateDon` |
| `order` | `asc` ou `desc` | `desc` |

> Dans une URL, `+` est interprété comme un espace. Écrire `A%2B` (ou `A+`, géré côté serveur).

Réponse paginée :

```json
{
  "data": [],
  "pagination": { "page": 1, "limit": 10, "total": 35, "totalPages": 4 }
}
```

## Exemples (curl)

```bash
curl "http://localhost:3000/api/dons?ville=Sousse&groupeSanguin=A%2B&page=1&limit=10"
curl "http://localhost:3000/api/dons?sortBy=volume&order=desc"
curl http://localhost:3000/api/donneurs/1/dons

curl -X POST http://localhost:3000/api/dons \
  -H "Content-Type: application/json" \
  -d '{"volume":450,"donneurId":1,"centreId":1}'

curl -X PATCH http://localhost:3000/api/dons/1 \
  -H "Content-Type: application/json" \
  -d '{"volume":500}'

curl -X DELETE http://localhost:3000/api/dons/1
```
