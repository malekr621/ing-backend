// Jeu de donnees de test : npm run seed
// ATTENTION : vide les tables Don, Donneur et Centre avant d'inserer.
import prisma from "../src/database/prisma.js";

await prisma.don.deleteMany();
await prisma.donneur.deleteMany();
await prisma.centre.deleteMany();

await prisma.centre.createMany({
  data: [
    { nom: "Centre régional de Sousse", ville: "Sousse" },
    { nom: "Centre régional de Tunis", ville: "Tunis" },
    { nom: "Centre régional de Sfax", ville: "Sfax" }
  ]
});

await prisma.donneur.createMany({
  data: [
    { nom: "Ben Ali", prenom: "Ahmed", groupeSanguin: "A+", telephone: "20111222" },
    { nom: "Trabelsi", prenom: "Sara", groupeSanguin: "O-", telephone: "20333444" },
    { nom: "Gharbi", prenom: "Youssef", groupeSanguin: "A+", telephone: null }
  ]
});

const centres = await prisma.centre.findMany({ orderBy: { id: "asc" } });
const donneurs = await prisma.donneur.findMany({ orderBy: { id: "asc" } });

await prisma.don.createMany({
  data: [
    { volume: 450, donneurId: donneurs[0].id, centreId: centres[0].id, dateDon: new Date("2026-01-10") },
    { volume: 450, donneurId: donneurs[0].id, centreId: centres[1].id, dateDon: new Date("2026-05-02") },
    { volume: 500, donneurId: donneurs[1].id, centreId: centres[0].id, dateDon: new Date("2026-03-21") },
    { volume: 400, donneurId: donneurs[2].id, centreId: centres[0].id, dateDon: new Date("2026-06-15") },
    { volume: 450, donneurId: donneurs[2].id, centreId: centres[2].id, dateDon: new Date("2026-09-01") }
  ]
});

console.log("Seed terminé.");
await prisma.$disconnect();
