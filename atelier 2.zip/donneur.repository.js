'use strict';

/**
 * Couche REPOSITORY : seul endroit qui connaît la source des données.
 * Ici, un simple tableau en mémoire (données entièrement fictives).
 * Remplacer ce fichier par une vraie base de données ne touche pas aux autres couches.
 */
const donneurs = [
  { id: 1, nom: 'Ben Ali', prenom: 'Ahmed', groupeSanguin: 'O+', ville: 'Tunis' },
  { id: 2, nom: 'Trabelsi', prenom: 'Sarra', groupeSanguin: 'A+', ville: 'Sfax' },
  { id: 3, nom: 'Gharbi', prenom: 'Youssef', groupeSanguin: 'B-', ville: 'Sousse' },
  { id: 4, nom: 'Mansouri', prenom: 'Leila', groupeSanguin: 'AB+', ville: 'Tunis' },
  { id: 5, nom: 'Jlassi', prenom: 'Karim', groupeSanguin: 'O-', ville: 'Bizerte' },
  { id: 6, nom: 'Hamdi', prenom: 'Nour', groupeSanguin: 'A-', ville: 'Nabeul' },
];

/** Compare sans tenir compte de la casse ni des accents. */
function normaliser(texte) {
  return String(texte)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Simule une panne de la source de données.
 * Activer avec : SIMULATE_REPO_ERROR=true node src/server.js
 */
function verifierDisponibilite() {
  if (process.env.SIMULATE_REPO_ERROR === 'true') {
    throw new Error('Erreur simulée : source de données indisponible');
  }
}

function findAll() {
  verifierDisponibilite();
  return [...donneurs];
}

function findById(id) {
  verifierDisponibilite();
  return donneurs.find((d) => d.id === id) || null;
}

function findByVille(ville) {
  verifierDisponibilite();
  const cible = normaliser(ville);
  return donneurs.filter((d) => normaliser(d.ville) === cible);
}

module.exports = { findAll, findById, findByVille };
