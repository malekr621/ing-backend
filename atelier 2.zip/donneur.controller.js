'use strict';

const donneurService = require('../services/donneur.service');
const { sendJson } = require('../utils/http');
const { AppError } = require('../utils/errors');

/**
 * Couche CONTROLLER : lit la requête HTTP, appelle le service, écrit la réponse.
 * C'est ici que les erreurs sont converties en codes HTTP.
 */

function gererErreur(res, err) {
  if (err instanceof AppError) {
    return sendJson(res, err.statusCode, {
      error: err.error,
      message: err.message,
      status: err.statusCode,
    });
  }

  // Erreur inattendue (ex. repository en panne) : on la journalise, mais on ne divulgue pas les détails.
  console.error('[ERREUR]', err.message);
  return sendJson(res, 500, {
    error: 'Erreur interne du serveur',
    message: 'Une erreur est survenue lors du traitement de la requête.',
    status: 500,
  });
}

function getAll(req, res, searchParams) {
  try {
    const ville = searchParams.has('ville') ? searchParams.get('ville') : undefined;
    const donneurs = donneurService.getDonneurs(ville);
    sendJson(res, 200, donneurs);
  } catch (err) {
    gererErreur(res, err);
  }
}

function getById(req, res, id) {
  try {
    const donneur = donneurService.getDonneurById(id);
    sendJson(res, 200, donneur);
  } catch (err) {
    gererErreur(res, err);
  }
}

module.exports = { getAll, getById };
