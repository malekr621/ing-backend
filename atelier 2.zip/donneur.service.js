'use strict';

const donneurRepository = require('../repositories/donneur.repository');
const { NotFoundError, BadRequestError } = require('../utils/errors');

/**
 * Couche SERVICE : règles métier et validation.
 * Elle ne connaît ni HTTP (req/res) ni la source des données.
 */

/**
 * Liste des donneurs, filtrée par ville si `ville` est fourni.
 * @param {string|undefined} ville  undefined = pas de filtre ; '' ou '   ' = erreur 400
 */
function getDonneurs(ville) {
  if (ville === undefined) {
    return donneurRepository.findAll();
  }

  if (ville.trim() === '') {
    throw new BadRequestError('Le paramètre "ville" ne doit pas être vide.');
  }

  return donneurRepository.findByVille(ville);
}

/**
 * Un donneur par identifiant.
 * @param {string} idBrut  identifiant tel que reçu dans l'URL (texte)
 */
function getDonneurById(idBrut) {
  if (!/^\d+$/.test(idBrut)) {
    throw new BadRequestError(`L'identifiant "${idBrut}" est invalide : un nombre entier est attendu.`);
  }

  const id = Number(idBrut);
  const donneur = donneurRepository.findById(id);

  if (!donneur) {
    throw new NotFoundError(`Aucun donneur avec l'identifiant ${id}.`);
  }

  return donneur;
}

module.exports = { getDonneurs, getDonneurById };
