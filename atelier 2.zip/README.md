# SangConnect — API de gestion des dons de sang

API HTTP en Node.js pur (module `http`, sans dépendance externe).

## 1. Instructions de lancement

Prérequis : Node.js 18 ou plus récent.

```bash
node src/server.js
```

Le serveur écoute sur `http://localhost:3000`.

Options :

```bash
PORT=4000 NODE_ENV=production node src/server.js
```

## 2. Structure

```
src/
├── server.js                         # serveur, routes simples, 404 / 405
├── routes/
│   └── donneur.routes.js             # URL -> méthode du controller
├── controllers/
│   └── donneur.controller.js         # HTTP <-> service, conversion des erreurs en codes HTTP
├── services/
│   └── donneur.service.js            # règles métier, validation
├── repositories/
│   └── donneur.repository.js         # accès aux données (tableau fictif)
└── utils/
    ├── http.js                       # sendJson(), sendMethodNotAllowed(), sendNotFound()
    └── errors.js                     # AppError, NotFoundError, BadRequestError
```

## 3. Routes et méthodes acceptées

| Route             | Méthodes acceptées | Description                                              |
|-------------------|--------------------|----------------------------------------------------------|
| `/api/welcome`    | `GET`              | Message de bienvenue                                     |
| `/api/version`    | `GET`              | Nom de l'application, version API, version Node, environnement |
| `/api/diagnostic` | `GET`              | Méthode, URL, date et en-têtes de la requête             |
| `/api/donneurs`   | `GET`              | Liste des donneurs (filtre optionnel `?ville=Tunis`)     |
| `/api/donneurs/:id` | `GET`            | Un donneur par identifiant                               |
| *(autre route)*   | —                  | Réponse 404 en JSON                                      |

## 4. Codes de statut utilisés

| Code | Signification        | Quand ?                                              |
|------|----------------------|------------------------------------------------------|
| 200  | OK                   | Route existante appelée avec une méthode autorisée   |
| 404  | Not Found            | Route non définie                                    |
| 405  | Method Not Allowed   | Route existante, méthode non autorisée (en-tête `Allow` ajouté) |
| 400  | Bad Request          | `?ville=` vide, ou identifiant non numérique (`/api/donneurs/abc`) |
| 500  | Internal Server Error | Erreur inattendue (ex. repository en panne), détails masqués au client |

## 5. Commandes curl (tests)

Route existante avec `GET` :

```bash
curl -i http://localhost:3000/api/welcome
curl -i http://localhost:3000/api/version
curl -i http://localhost:3000/api/diagnostic
```

Route inexistante (404) :

```bash
curl -i http://localhost:3000/api/inconnue
```

Route existante avec méthode non autorisée (405) :

```bash
curl -i -X POST   http://localhost:3000/api/diagnostic
curl -i -X DELETE http://localhost:3000/api/welcome
```

Plusieurs routes à la suite :

```bash
curl -i http://localhost:3000/api/welcome http://localhost:3000/api/version http://localhost:3000/api/inconnue
```

### Exemples de réponses

`GET /api/welcome` → `200`

```json
{
  "message": "Bienvenue dans l’API SangConnect",
  "description": "Gestion des dons de sang"
}
```

`POST /api/diagnostic` → `405` (en-tête `Allow: GET`)

```json
{
  "error": "Méthode non autorisée",
  "message": "La méthode POST n'est pas autorisée sur /api/diagnostic. Utilisez : GET.",
  "path": "/api/diagnostic",
  "method": "POST",
  "allowedMethods": ["GET"]
}
```

`GET /api/inconnue` → `404`

```json
{
  "error": "Route non trouvée",
  "path": "/api/inconnue",
  "method": "GET",
  "timestamp": "2026-11-08T10:00:00.000Z"
}
```

## 6. Explication de `sendJson()`

```js
sendJson(res, statusCode, data, headers = {})
```

Cette fonction centralise l'envoi des réponses JSON afin d'éviter de répéter le même code dans chaque route :

1. `JSON.stringify(data, null, 2)` convertit l'objet JavaScript en texte JSON lisible.
2. `res.writeHead(statusCode, {...})` envoie le code de statut et les en-têtes :
   - `Content-Type: application/json; charset=utf-8` indique au client que le corps est du JSON (UTF-8, pour les accents) ;
   - `Content-Length` donne la taille exacte du corps en octets (`Buffer.byteLength`, car un caractère accentué fait plus d'un octet) ;
   - `headers` permet d'ajouter des en-têtes propres à un cas, par exemple `Allow` pour un 405.
3. `res.end(body)` envoie le corps et termine la réponse.

`sendMethodNotAllowed()` et `sendNotFound()` s'appuient sur `sendJson()` pour produire les réponses 405 et 404.

---

## 7. Gestion des donneurs : architecture en couches

Une requête traverse quatre couches. Chaque couche n'appelle que celle située juste en dessous.

```
Requête HTTP
   │
   ▼
routes/donneur.routes.js        Quelle URL ? Quelle méthode ? -> choisit le controller
   │
   ▼
controllers/donneur.controller  Lit la requête (id, ?ville), appelle le service,
   │                            écrit la réponse JSON, convertit les erreurs en codes HTTP
   ▼
services/donneur.service        Règles métier : validation (ville vide, id invalide),
   │                            donneur introuvable -> NotFoundError
   ▼
repositories/donneur.repository Accès aux données : findAll, findById, findByVille
                                (tableau en mémoire, données fictives)
```

### Rôle de chaque couche

| Couche      | Responsabilité                                             | Ne doit PAS                          |
|-------------|------------------------------------------------------------|--------------------------------------|
| Routes      | Associer URL + méthode à une fonction du controller        | Contenir de la logique               |
| Controller  | Traduire HTTP <-> appels de service ; erreurs -> codes HTTP | Accéder aux données, valider le métier |
| Service     | Validation et règles métier ; lever des erreurs typées     | Connaître `req` / `res`              |
| Repository  | Lire les données                                           | Connaître HTTP ou les règles métier  |

**Avantage :** remplacer le tableau par une vraie base de données ne change que le repository ; les autres couches restent intactes.

### Où se fait la recherche par ville ?

- La **validation** (ville vide -> 400) est dans le **service**, car c'est une règle métier.
- Le **filtrage** est dans le **repository** (`findByVille`), car c'est une opération sur les données. La comparaison ignore la casse et les accents (`tunis`, `TUNIS` et `Tunis` donnent le même résultat).
- Le **controller** se contente de lire `?ville=` et de transmettre la valeur.

### Données fictives

Six donneurs sont définis dans `src/repositories/donneur.repository.js` (id 1 à 6), au format :

```js
{ id: 1, nom: "Ben Ali", prenom: "Ahmed", groupeSanguin: "O+", ville: "Tunis" }
```

### Gestion des erreurs

| Situation              | Où elle est détectée | Réponse |
|------------------------|----------------------|---------|
| Donneur inexistant     | service (`NotFoundError`)    | 404 |
| Ville vide             | service (`BadRequestError`)  | 400 |
| Id non numérique       | service (`BadRequestError`)  | 400 |
| Erreur du repository   | repository (`Error`), interceptée par le controller | 500 (message générique, détail dans la console du serveur) |

Corps d'erreur type :

```json
{ "error": "Ressource non trouvée", "message": "Aucun donneur avec l'identifiant 999.", "status": 404 }
```

Pour simuler une panne du repository :

```bash
SIMULATE_REPO_ERROR=true node src/server.js
```

## 8. Tests curl : donneurs

```bash
# Liste des donneurs -> 200
curl -i http://localhost:3000/api/donneurs

# Un donneur -> 200
curl -i http://localhost:3000/api/donneurs/1

# Donneur inexistant -> 404
curl -i http://localhost:3000/api/donneurs/999

# Recherche par ville -> 200 (Ahmed et Leila)
curl -i "http://localhost:3000/api/donneurs?ville=Tunis"

# Ville vide -> 400
curl -i "http://localhost:3000/api/donneurs?ville="

# Identifiant invalide -> 400
curl -i http://localhost:3000/api/donneurs/abc

# Méthode non autorisée -> 405 (en-tête Allow: GET)
curl -i -X POST http://localhost:3000/api/donneurs

# Erreur simulée du repository -> 500 (relancer le serveur avec SIMULATE_REPO_ERROR=true)
curl -i http://localhost:3000/api/donneurs
```
