'use strict';

const donneurController = require('../controllers/donneur.controller');
const { sendMethodNotAllowed } = require('../utils/http');

const ALLOWED = ['GET'];

/**
 * Couche ROUTES : associe une URL à une méthode de controller.
 *
 * @returns {boolean} true si la requête a été prise en charge, false sinon
 *                    (le serveur poursuit alors avec les autres routes / le 404).
 */
function handleDonneurRoutes(req, res, pathname, searchParams) {
  // /api/donneurs
  if (/^\/api\/donneurs\/?$/.test(pathname)) {
    if (!ALLOWED.includes(req.method)) {
      sendMethodNotAllowed(req, res, pathname, ALLOWED);
    } else {
      donneurController.getAll(req, res, searchParams);
    }
    return true;
  }

  // /api/donneurs/:id
  const match = pathname.match(/^\/api\/donneurs\/([^/]+)\/?$/);
  if (match) {
    if (!ALLOWED.includes(req.method)) {
      sendMethodNotAllowed(req, res, pathname, ALLOWED);
    } else {
      donneurController.getById(req, res, decodeURIComponent(match[1]));
    }
    return true;
  }

  return false;
}

module.exports = { handleDonneurRoutes };
